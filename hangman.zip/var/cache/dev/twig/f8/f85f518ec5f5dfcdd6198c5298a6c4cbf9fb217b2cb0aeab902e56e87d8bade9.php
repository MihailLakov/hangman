<?php

/* default/403.html.twig */
class __TwigTemplate_e8ba80523f760143bb1516ea796a0688d38b3c73a9dda6d405d56186c953ca9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/403.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_86c97c8c7564844c2ed402d4085081910b241765b3592df6de4dac292788815d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86c97c8c7564844c2ed402d4085081910b241765b3592df6de4dac292788815d->enter($__internal_86c97c8c7564844c2ed402d4085081910b241765b3592df6de4dac292788815d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/403.html.twig"));

        $__internal_4b5f930fad736b9b85ace1c286e452e90c0018df7a7956220faeb4046d0e40b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b5f930fad736b9b85ace1c286e452e90c0018df7a7956220faeb4046d0e40b1->enter($__internal_4b5f930fad736b9b85ace1c286e452e90c0018df7a7956220faeb4046d0e40b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_86c97c8c7564844c2ed402d4085081910b241765b3592df6de4dac292788815d->leave($__internal_86c97c8c7564844c2ed402d4085081910b241765b3592df6de4dac292788815d_prof);

        
        $__internal_4b5f930fad736b9b85ace1c286e452e90c0018df7a7956220faeb4046d0e40b1->leave($__internal_4b5f930fad736b9b85ace1c286e452e90c0018df7a7956220faeb4046d0e40b1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c247182b9be7ccb0e674b60e6116b7c19da9b20fa37f71f3c8fda20611dd063d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c247182b9be7ccb0e674b60e6116b7c19da9b20fa37f71f3c8fda20611dd063d->enter($__internal_c247182b9be7ccb0e674b60e6116b7c19da9b20fa37f71f3c8fda20611dd063d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_94025a323ea302e7da3692240178a6b6221ba70db33315dd34dd691acb7db61b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94025a323ea302e7da3692240178a6b6221ba70db33315dd34dd691acb7db61b->enter($__internal_94025a323ea302e7da3692240178a6b6221ba70db33315dd34dd691acb7db61b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <h1> 403 :(</h1>
            <h2> You tried to access an unauthorised page, please log in to continue</h2>       
            <div class=\"well\">                     
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-login");
        echo "\" class=\"btn-lg btn-primary\" style=\"margin: 0 auto; position:relative; display:block; max-width:380px;text-align:center;\"> Log in with approriate credentials</a>
            </div>
        </div>
    </div>
";
        
        $__internal_94025a323ea302e7da3692240178a6b6221ba70db33315dd34dd691acb7db61b->leave($__internal_94025a323ea302e7da3692240178a6b6221ba70db33315dd34dd691acb7db61b_prof);

        
        $__internal_c247182b9be7ccb0e674b60e6116b7c19da9b20fa37f71f3c8fda20611dd063d->leave($__internal_c247182b9be7ccb0e674b60e6116b7c19da9b20fa37f71f3c8fda20611dd063d_prof);

    }

    public function getTemplateName()
    {
        return "default/403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <h1> 403 :(</h1>
            <h2> You tried to access an unauthorised page, please log in to continue</h2>       
            <div class=\"well\">                     
                <a href=\"{{path('security-login')}}\" class=\"btn-lg btn-primary\" style=\"margin: 0 auto; position:relative; display:block; max-width:380px;text-align:center;\"> Log in with approriate credentials</a>
            </div>
        </div>
    </div>
{% endblock %}
", "default/403.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\default\\403.html.twig");
    }
}
