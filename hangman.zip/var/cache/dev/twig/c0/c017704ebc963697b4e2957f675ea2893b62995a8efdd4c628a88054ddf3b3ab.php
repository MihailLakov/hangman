<?php

/* :category:new.html.twig */
class __TwigTemplate_9df30d797e8951759015d4633d166ad5ead5ef32d8cfd6246a2b863a8a8d6b5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68db02e42cb099c0b16800e55d43cf93c752da20da9a90286bc9d728bcfb045d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68db02e42cb099c0b16800e55d43cf93c752da20da9a90286bc9d728bcfb045d->enter($__internal_68db02e42cb099c0b16800e55d43cf93c752da20da9a90286bc9d728bcfb045d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:new.html.twig"));

        $__internal_45dcfe781552b349083d7f10f2742a65dc12df9a6ac7e6c1b0d190ef2b6023ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45dcfe781552b349083d7f10f2742a65dc12df9a6ac7e6c1b0d190ef2b6023ed->enter($__internal_45dcfe781552b349083d7f10f2742a65dc12df9a6ac7e6c1b0d190ef2b6023ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_68db02e42cb099c0b16800e55d43cf93c752da20da9a90286bc9d728bcfb045d->leave($__internal_68db02e42cb099c0b16800e55d43cf93c752da20da9a90286bc9d728bcfb045d_prof);

        
        $__internal_45dcfe781552b349083d7f10f2742a65dc12df9a6ac7e6c1b0d190ef2b6023ed->leave($__internal_45dcfe781552b349083d7f10f2742a65dc12df9a6ac7e6c1b0d190ef2b6023ed_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_760cb3b5eb0e7b42f95df32bc028a6e5a48f2b3744432eaa2a8b0ca8927c10b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_760cb3b5eb0e7b42f95df32bc028a6e5a48f2b3744432eaa2a8b0ca8927c10b9->enter($__internal_760cb3b5eb0e7b42f95df32bc028a6e5a48f2b3744432eaa2a8b0ca8927c10b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e2f968658f6a6af1281e88e78acc5bff1d3557fadc8c1c775bbc2b9dacb1362f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2f968658f6a6af1281e88e78acc5bff1d3557fadc8c1c775bbc2b9dacb1362f->enter($__internal_e2f968658f6a6af1281e88e78acc5bff1d3557fadc8c1c775bbc2b9dacb1362f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category creation</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\"/>
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_e2f968658f6a6af1281e88e78acc5bff1d3557fadc8c1c775bbc2b9dacb1362f->leave($__internal_e2f968658f6a6af1281e88e78acc5bff1d3557fadc8c1c775bbc2b9dacb1362f_prof);

        
        $__internal_760cb3b5eb0e7b42f95df32bc028a6e5a48f2b3744432eaa2a8b0ca8927c10b9->leave($__internal_760cb3b5eb0e7b42f95df32bc028a6e5a48f2b3744432eaa2a8b0ca8927c10b9_prof);

    }

    public function getTemplateName()
    {
        return ":category:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category creation</h1>

                    {{ form_start(form) }}
                    {{ form_widget(form) }}
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\"/>
                    {{ form_end(form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":category:new.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/category/new.html.twig");
    }
}
