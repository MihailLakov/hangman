<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_567a207026c5541abeea390c2dee98c6fb867c915aa886bb88ec46f6fa256257 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad34ef3f809994099655fc4fbb34d98e86b85dc4795e691682b7ccfa1193fe35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad34ef3f809994099655fc4fbb34d98e86b85dc4795e691682b7ccfa1193fe35->enter($__internal_ad34ef3f809994099655fc4fbb34d98e86b85dc4795e691682b7ccfa1193fe35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_7803e0b84425ddc04248697ecbd998665f4737cfef63873ef42ea1e442ca8834 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7803e0b84425ddc04248697ecbd998665f4737cfef63873ef42ea1e442ca8834->enter($__internal_7803e0b84425ddc04248697ecbd998665f4737cfef63873ef42ea1e442ca8834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_ad34ef3f809994099655fc4fbb34d98e86b85dc4795e691682b7ccfa1193fe35->leave($__internal_ad34ef3f809994099655fc4fbb34d98e86b85dc4795e691682b7ccfa1193fe35_prof);

        
        $__internal_7803e0b84425ddc04248697ecbd998665f4737cfef63873ef42ea1e442ca8834->leave($__internal_7803e0b84425ddc04248697ecbd998665f4737cfef63873ef42ea1e442ca8834_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
