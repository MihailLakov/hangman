<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_d28e3bf5e89303216dc65eb71f36e879639dbc5effbea8ab405e40b761eeeedc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_065bc24648b6dd41cb014dd7461e70d6f09e0cc849f2444626bd88d881f49dc8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_065bc24648b6dd41cb014dd7461e70d6f09e0cc849f2444626bd88d881f49dc8->enter($__internal_065bc24648b6dd41cb014dd7461e70d6f09e0cc849f2444626bd88d881f49dc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_fef2271aff86073180fc56b159e228d1a33787ecd2fa475fe0b2372406fd1395 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fef2271aff86073180fc56b159e228d1a33787ecd2fa475fe0b2372406fd1395->enter($__internal_fef2271aff86073180fc56b159e228d1a33787ecd2fa475fe0b2372406fd1395_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_065bc24648b6dd41cb014dd7461e70d6f09e0cc849f2444626bd88d881f49dc8->leave($__internal_065bc24648b6dd41cb014dd7461e70d6f09e0cc849f2444626bd88d881f49dc8_prof);

        
        $__internal_fef2271aff86073180fc56b159e228d1a33787ecd2fa475fe0b2372406fd1395->leave($__internal_fef2271aff86073180fc56b159e228d1a33787ecd2fa475fe0b2372406fd1395_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
