<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_962e36dd7239c1464884932fbb52a8753ea9421e99719a7f5bdad27552086077 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c87851ad74bc52cbd00c683435ca77dbf80ea8dbb8fac0b7b3bf812ce725601f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c87851ad74bc52cbd00c683435ca77dbf80ea8dbb8fac0b7b3bf812ce725601f->enter($__internal_c87851ad74bc52cbd00c683435ca77dbf80ea8dbb8fac0b7b3bf812ce725601f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_8aa03c8edfdaea52bc4b13ce8e506c91b7055e8ce8d58778440039c8d1944957 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8aa03c8edfdaea52bc4b13ce8e506c91b7055e8ce8d58778440039c8d1944957->enter($__internal_8aa03c8edfdaea52bc4b13ce8e506c91b7055e8ce8d58778440039c8d1944957_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_c87851ad74bc52cbd00c683435ca77dbf80ea8dbb8fac0b7b3bf812ce725601f->leave($__internal_c87851ad74bc52cbd00c683435ca77dbf80ea8dbb8fac0b7b3bf812ce725601f_prof);

        
        $__internal_8aa03c8edfdaea52bc4b13ce8e506c91b7055e8ce8d58778440039c8d1944957->leave($__internal_8aa03c8edfdaea52bc4b13ce8e506c91b7055e8ce8d58778440039c8d1944957_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
