<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_1aadbcff202752c66319e5d55c70818dfbcd856abef7eade6bd45bb75ba0e77a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b1da15e133b9665de24c2aa4a769f6080c9e0e03c55970222f95fbfc192d3a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b1da15e133b9665de24c2aa4a769f6080c9e0e03c55970222f95fbfc192d3a2->enter($__internal_6b1da15e133b9665de24c2aa4a769f6080c9e0e03c55970222f95fbfc192d3a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_0e9de7730d125102ca9b9dca0f3570746648917b044d718c0f13ba15d1d99428 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e9de7730d125102ca9b9dca0f3570746648917b044d718c0f13ba15d1d99428->enter($__internal_0e9de7730d125102ca9b9dca0f3570746648917b044d718c0f13ba15d1d99428_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b1da15e133b9665de24c2aa4a769f6080c9e0e03c55970222f95fbfc192d3a2->leave($__internal_6b1da15e133b9665de24c2aa4a769f6080c9e0e03c55970222f95fbfc192d3a2_prof);

        
        $__internal_0e9de7730d125102ca9b9dca0f3570746648917b044d718c0f13ba15d1d99428->leave($__internal_0e9de7730d125102ca9b9dca0f3570746648917b044d718c0f13ba15d1d99428_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_14b5193a6e36cd3be892519a01d9f1138a9a2c705600a8edd9e257be5b7bf581 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14b5193a6e36cd3be892519a01d9f1138a9a2c705600a8edd9e257be5b7bf581->enter($__internal_14b5193a6e36cd3be892519a01d9f1138a9a2c705600a8edd9e257be5b7bf581_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_e318e2aa51012174459531535e7d074e4fe24742b20dcc64f89e1a46d6ff5eca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e318e2aa51012174459531535e7d074e4fe24742b20dcc64f89e1a46d6ff5eca->enter($__internal_e318e2aa51012174459531535e7d074e4fe24742b20dcc64f89e1a46d6ff5eca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_e318e2aa51012174459531535e7d074e4fe24742b20dcc64f89e1a46d6ff5eca->leave($__internal_e318e2aa51012174459531535e7d074e4fe24742b20dcc64f89e1a46d6ff5eca_prof);

        
        $__internal_14b5193a6e36cd3be892519a01d9f1138a9a2c705600a8edd9e257be5b7bf581->leave($__internal_14b5193a6e36cd3be892519a01d9f1138a9a2c705600a8edd9e257be5b7bf581_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_f99512b76d78bb681e4fc158ad0c25e3cd20907700c9411e16df14e85bc07994 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f99512b76d78bb681e4fc158ad0c25e3cd20907700c9411e16df14e85bc07994->enter($__internal_f99512b76d78bb681e4fc158ad0c25e3cd20907700c9411e16df14e85bc07994_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_31a912140a160ced1c967111c9a59ed6ed4a05f02114b6b01218488da1c43557 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31a912140a160ced1c967111c9a59ed6ed4a05f02114b6b01218488da1c43557->enter($__internal_31a912140a160ced1c967111c9a59ed6ed4a05f02114b6b01218488da1c43557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_31a912140a160ced1c967111c9a59ed6ed4a05f02114b6b01218488da1c43557->leave($__internal_31a912140a160ced1c967111c9a59ed6ed4a05f02114b6b01218488da1c43557_prof);

        
        $__internal_f99512b76d78bb681e4fc158ad0c25e3cd20907700c9411e16df14e85bc07994->leave($__internal_f99512b76d78bb681e4fc158ad0c25e3cd20907700c9411e16df14e85bc07994_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
