<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_dcf1a5437117ce41a357013b25ff33ab71d8fe5351a3af5a2898ae37a6995555 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d84c697637456d0b47c3288c4f394bbf493b380b7b4e2dcef202a19595b96cd1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d84c697637456d0b47c3288c4f394bbf493b380b7b4e2dcef202a19595b96cd1->enter($__internal_d84c697637456d0b47c3288c4f394bbf493b380b7b4e2dcef202a19595b96cd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_fdfd378f0ec258e97ac6a0f785bbdae64f7ed2a5970d0a4707adef980fbbb3ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdfd378f0ec258e97ac6a0f785bbdae64f7ed2a5970d0a4707adef980fbbb3ef->enter($__internal_fdfd378f0ec258e97ac6a0f785bbdae64f7ed2a5970d0a4707adef980fbbb3ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_d84c697637456d0b47c3288c4f394bbf493b380b7b4e2dcef202a19595b96cd1->leave($__internal_d84c697637456d0b47c3288c4f394bbf493b380b7b4e2dcef202a19595b96cd1_prof);

        
        $__internal_fdfd378f0ec258e97ac6a0f785bbdae64f7ed2a5970d0a4707adef980fbbb3ef->leave($__internal_fdfd378f0ec258e97ac6a0f785bbdae64f7ed2a5970d0a4707adef980fbbb3ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
