<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_71375d8dabc277386083c04a31bad1accbe33ddd9e2dac47c6be75235f6ce7fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_510aaf50943b235638acaf5e34dbdabd07ef1d1c7e4b1d5118ac6fd4fb54b643 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_510aaf50943b235638acaf5e34dbdabd07ef1d1c7e4b1d5118ac6fd4fb54b643->enter($__internal_510aaf50943b235638acaf5e34dbdabd07ef1d1c7e4b1d5118ac6fd4fb54b643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_4405a7bb374b33767b7781b0fdc488c87fc84e69624c5acf5961217c7e27858a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4405a7bb374b33767b7781b0fdc488c87fc84e69624c5acf5961217c7e27858a->enter($__internal_4405a7bb374b33767b7781b0fdc488c87fc84e69624c5acf5961217c7e27858a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_510aaf50943b235638acaf5e34dbdabd07ef1d1c7e4b1d5118ac6fd4fb54b643->leave($__internal_510aaf50943b235638acaf5e34dbdabd07ef1d1c7e4b1d5118ac6fd4fb54b643_prof);

        
        $__internal_4405a7bb374b33767b7781b0fdc488c87fc84e69624c5acf5961217c7e27858a->leave($__internal_4405a7bb374b33767b7781b0fdc488c87fc84e69624c5acf5961217c7e27858a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
