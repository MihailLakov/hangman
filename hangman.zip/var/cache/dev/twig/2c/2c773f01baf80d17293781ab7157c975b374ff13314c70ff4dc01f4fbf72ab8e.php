<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_657c5fffd2b9b00181fb80b862d675320ae4f0ba7d76cccdfcb7394196dce994 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75131c1a32a78c3883cd6726d0915fb288549257e4684c2ef42d190fc97c7421 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75131c1a32a78c3883cd6726d0915fb288549257e4684c2ef42d190fc97c7421->enter($__internal_75131c1a32a78c3883cd6726d0915fb288549257e4684c2ef42d190fc97c7421_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_4368915b09c72bf8f6395c2b796eb786c18da0255cfda223fa97a7da342083a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4368915b09c72bf8f6395c2b796eb786c18da0255cfda223fa97a7da342083a8->enter($__internal_4368915b09c72bf8f6395c2b796eb786c18da0255cfda223fa97a7da342083a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_75131c1a32a78c3883cd6726d0915fb288549257e4684c2ef42d190fc97c7421->leave($__internal_75131c1a32a78c3883cd6726d0915fb288549257e4684c2ef42d190fc97c7421_prof);

        
        $__internal_4368915b09c72bf8f6395c2b796eb786c18da0255cfda223fa97a7da342083a8->leave($__internal_4368915b09c72bf8f6395c2b796eb786c18da0255cfda223fa97a7da342083a8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
