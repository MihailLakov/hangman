<?php

/* :admin:index.html.twig */
class __TwigTemplate_1fec48cd409fc1c05ff0555c433244de507df4472e39b3c4f24faa2ca7b50f79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":admin:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a62de0ec3cffab05ffba64f2b02af7983782c00a09858692a7a2b242bbe50737 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a62de0ec3cffab05ffba64f2b02af7983782c00a09858692a7a2b242bbe50737->enter($__internal_a62de0ec3cffab05ffba64f2b02af7983782c00a09858692a7a2b242bbe50737_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin:index.html.twig"));

        $__internal_5c7ebeab6b7299d88d839a7de08f0988854b7871651363cc4d2251182f5dcde3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c7ebeab6b7299d88d839a7de08f0988854b7871651363cc4d2251182f5dcde3->enter($__internal_5c7ebeab6b7299d88d839a7de08f0988854b7871651363cc4d2251182f5dcde3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a62de0ec3cffab05ffba64f2b02af7983782c00a09858692a7a2b242bbe50737->leave($__internal_a62de0ec3cffab05ffba64f2b02af7983782c00a09858692a7a2b242bbe50737_prof);

        
        $__internal_5c7ebeab6b7299d88d839a7de08f0988854b7871651363cc4d2251182f5dcde3->leave($__internal_5c7ebeab6b7299d88d839a7de08f0988854b7871651363cc4d2251182f5dcde3_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_41960b9130ee75dfb2d2b687e32eb9cfd8a8e51a669ad84ac210e792856dd6ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41960b9130ee75dfb2d2b687e32eb9cfd8a8e51a669ad84ac210e792856dd6ae->enter($__internal_41960b9130ee75dfb2d2b687e32eb9cfd8a8e51a669ad84ac210e792856dd6ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_363e76d9c4738a9a3d0c869279a4fe64c3278da4e1a96f9fe02a6039541f7727 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_363e76d9c4738a9a3d0c869279a4fe64c3278da4e1a96f9fe02a6039541f7727->enter($__internal_363e76d9c4738a9a3d0c869279a4fe64c3278da4e1a96f9fe02a6039541f7727_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Admin panel</h1>                
                <hr>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Manage words</a>
                <hr>
                <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Manage categories</a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_363e76d9c4738a9a3d0c869279a4fe64c3278da4e1a96f9fe02a6039541f7727->leave($__internal_363e76d9c4738a9a3d0c869279a4fe64c3278da4e1a96f9fe02a6039541f7727_prof);

        
        $__internal_41960b9130ee75dfb2d2b687e32eb9cfd8a8e51a669ad84ac210e792856dd6ae->leave($__internal_41960b9130ee75dfb2d2b687e32eb9cfd8a8e51a669ad84ac210e792856dd6ae_prof);

    }

    public function getTemplateName()
    {
        return ":admin:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 11,  57 => 9,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Admin panel</h1>                
                <hr>
                <a href=\"{{ path('word_index') }}\" class=\"btn btn-lg btn-primary btn-block\">Manage words</a>
                <hr>
                <a href=\"{{ path('category_index') }}\" class=\"btn btn-lg btn-primary btn-block\">Manage categories</a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":admin:index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/admin/index.html.twig");
    }
}
