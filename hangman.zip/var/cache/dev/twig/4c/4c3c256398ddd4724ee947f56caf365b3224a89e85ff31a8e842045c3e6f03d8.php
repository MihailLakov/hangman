<?php

/* :category:edit.html.twig */
class __TwigTemplate_327237cd633efd5d51e709a0d01b0f68834b79b6125656be22848dfaabc1d280 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_979d1fb8f6fb85356b67adadb52a984223161bd72feb9f5b7e9be74c89cdd0c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_979d1fb8f6fb85356b67adadb52a984223161bd72feb9f5b7e9be74c89cdd0c1->enter($__internal_979d1fb8f6fb85356b67adadb52a984223161bd72feb9f5b7e9be74c89cdd0c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:edit.html.twig"));

        $__internal_c8541397aedfc7dca0bb51f7185a62981f2e6bf5d3eca770d019a653ca425673 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8541397aedfc7dca0bb51f7185a62981f2e6bf5d3eca770d019a653ca425673->enter($__internal_c8541397aedfc7dca0bb51f7185a62981f2e6bf5d3eca770d019a653ca425673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_979d1fb8f6fb85356b67adadb52a984223161bd72feb9f5b7e9be74c89cdd0c1->leave($__internal_979d1fb8f6fb85356b67adadb52a984223161bd72feb9f5b7e9be74c89cdd0c1_prof);

        
        $__internal_c8541397aedfc7dca0bb51f7185a62981f2e6bf5d3eca770d019a653ca425673->leave($__internal_c8541397aedfc7dca0bb51f7185a62981f2e6bf5d3eca770d019a653ca425673_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_674eeb447b81a4bcd55d8829c172bc392e61f789a147a07d288d4357568a7e05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_674eeb447b81a4bcd55d8829c172bc392e61f789a147a07d288d4357568a7e05->enter($__internal_674eeb447b81a4bcd55d8829c172bc392e61f789a147a07d288d4357568a7e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f579dbdc5efead658483a3b19e37a6109e781545c55c0051bac5d96f971edb4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f579dbdc5efead658483a3b19e37a6109e781545c55c0051bac5d96f971edb4c->enter($__internal_f579dbdc5efead658483a3b19e37a6109e781545c55c0051bac5d96f971edb4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Category Edit</h1>
                ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
                ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
                <input type=\"submit\" value=\"Submit edit\" class=\"btn btn-info\" />
                ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "
                <ul>
                    <li>
                        <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                    </li>
                    <li>
                        ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                        <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                        ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                    </li>
                </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_f579dbdc5efead658483a3b19e37a6109e781545c55c0051bac5d96f971edb4c->leave($__internal_f579dbdc5efead658483a3b19e37a6109e781545c55c0051bac5d96f971edb4c_prof);

        
        $__internal_674eeb447b81a4bcd55d8829c172bc392e61f789a147a07d288d4357568a7e05->leave($__internal_674eeb447b81a4bcd55d8829c172bc392e61f789a147a07d288d4357568a7e05_prof);

    }

    public function getTemplateName()
    {
        return ":category:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 20,  77 => 18,  71 => 15,  65 => 12,  60 => 10,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Category Edit</h1>
                {{ form_start(edit_form) }}
                {{ form_widget(edit_form) }}
                <input type=\"submit\" value=\"Submit edit\" class=\"btn btn-info\" />
                {{ form_end(edit_form) }}
                <ul>
                    <li>
                        <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                    </li>
                    <li>
                        {{ form_start(delete_form) }}
                        <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                        {{ form_end(delete_form) }}
                    </li>
                </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":category:edit.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/category/edit.html.twig");
    }
}
