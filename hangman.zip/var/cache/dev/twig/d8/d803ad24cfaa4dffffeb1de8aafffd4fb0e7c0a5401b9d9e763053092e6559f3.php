<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_48d6fcfb5619ce8ba5c6b5865aa9314e070904e0335cae6a6b5233d7a3ced4ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa9f3e118e5856132859db3de716798b1ec685e3265e4d45f79dec606a604a4e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa9f3e118e5856132859db3de716798b1ec685e3265e4d45f79dec606a604a4e->enter($__internal_aa9f3e118e5856132859db3de716798b1ec685e3265e4d45f79dec606a604a4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_a523eae26c91aeb0f76c0b7e01077406a6bd54ca92bce98bfe02ba21b21375ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a523eae26c91aeb0f76c0b7e01077406a6bd54ca92bce98bfe02ba21b21375ff->enter($__internal_a523eae26c91aeb0f76c0b7e01077406a6bd54ca92bce98bfe02ba21b21375ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_aa9f3e118e5856132859db3de716798b1ec685e3265e4d45f79dec606a604a4e->leave($__internal_aa9f3e118e5856132859db3de716798b1ec685e3265e4d45f79dec606a604a4e_prof);

        
        $__internal_a523eae26c91aeb0f76c0b7e01077406a6bd54ca92bce98bfe02ba21b21375ff->leave($__internal_a523eae26c91aeb0f76c0b7e01077406a6bd54ca92bce98bfe02ba21b21375ff_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
