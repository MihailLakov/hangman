<?php

/* :default:index.html.twig */
class __TwigTemplate_71e7ade6a2d7dcddd50b45603c3a026bf06fbcc2e0b18526c43f261a6cfff536 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc4c38eaa6630eaee707d270206f1714d1051b83e6771519b128750f344b851e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc4c38eaa6630eaee707d270206f1714d1051b83e6771519b128750f344b851e->enter($__internal_dc4c38eaa6630eaee707d270206f1714d1051b83e6771519b128750f344b851e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:index.html.twig"));

        $__internal_1edca1278d711671d8a0c66c18678cd21215d1a910979727c01a9f3187633d34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1edca1278d711671d8a0c66c18678cd21215d1a910979727c01a9f3187633d34->enter($__internal_1edca1278d711671d8a0c66c18678cd21215d1a910979727c01a9f3187633d34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dc4c38eaa6630eaee707d270206f1714d1051b83e6771519b128750f344b851e->leave($__internal_dc4c38eaa6630eaee707d270206f1714d1051b83e6771519b128750f344b851e_prof);

        
        $__internal_1edca1278d711671d8a0c66c18678cd21215d1a910979727c01a9f3187633d34->leave($__internal_1edca1278d711671d8a0c66c18678cd21215d1a910979727c01a9f3187633d34_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_1b4abd6b1f51cf5ec31c9dbc4a4df8e673448a092a60bbd739db2db94bea3a24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b4abd6b1f51cf5ec31c9dbc4a4df8e673448a092a60bbd739db2db94bea3a24->enter($__internal_1b4abd6b1f51cf5ec31c9dbc4a4df8e673448a092a60bbd739db2db94bea3a24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8a20564f8bdc54e933535ce7a95f79e61d6edfaf06bce0ff02766acb5c992bb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a20564f8bdc54e933535ce7a95f79e61d6edfaf06bce0ff02766acb5c992bb4->enter($__internal_8a20564f8bdc54e933535ce7a95f79e61d6edfaf06bce0ff02766acb5c992bb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Welcome to Hangman game</h1>     
                    <hr>
                    <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Start a new game!</a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_8a20564f8bdc54e933535ce7a95f79e61d6edfaf06bce0ff02766acb5c992bb4->leave($__internal_8a20564f8bdc54e933535ce7a95f79e61d6edfaf06bce0ff02766acb5c992bb4_prof);

        
        $__internal_1b4abd6b1f51cf5ec31c9dbc4a4df8e673448a092a60bbd739db2db94bea3a24->leave($__internal_1b4abd6b1f51cf5ec31c9dbc4a4df8e673448a092a60bbd739db2db94bea3a24_prof);

    }

    public function getTemplateName()
    {
        return ":default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 9,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Welcome to Hangman game</h1>     
                    <hr>
                    <a href=\"{{ path('game') }}\" class=\"btn btn-lg btn-primary btn-block\">Start a new game!</a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":default:index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/default/index.html.twig");
    }
}
