<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_d4089c4e374fa22a4ecc9d6cb6640ad2580b6a179230c6fabde44da95e266f8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_686716bf8b400bf9dfc47ffcdf1bfd96344223a0974a3f06e3f0cf1db9d929b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_686716bf8b400bf9dfc47ffcdf1bfd96344223a0974a3f06e3f0cf1db9d929b2->enter($__internal_686716bf8b400bf9dfc47ffcdf1bfd96344223a0974a3f06e3f0cf1db9d929b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_ce4182674deda7259c6316818bb932fa69e057278da53e32b4f51b1cad239aff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce4182674deda7259c6316818bb932fa69e057278da53e32b4f51b1cad239aff->enter($__internal_ce4182674deda7259c6316818bb932fa69e057278da53e32b4f51b1cad239aff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_686716bf8b400bf9dfc47ffcdf1bfd96344223a0974a3f06e3f0cf1db9d929b2->leave($__internal_686716bf8b400bf9dfc47ffcdf1bfd96344223a0974a3f06e3f0cf1db9d929b2_prof);

        
        $__internal_ce4182674deda7259c6316818bb932fa69e057278da53e32b4f51b1cad239aff->leave($__internal_ce4182674deda7259c6316818bb932fa69e057278da53e32b4f51b1cad239aff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
