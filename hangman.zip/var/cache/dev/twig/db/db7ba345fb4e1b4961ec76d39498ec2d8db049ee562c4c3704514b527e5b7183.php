<?php

/* :category:show.html.twig */
class __TwigTemplate_2d502800b65ac3f88de9fe34462c8ad2dcb8d03bc26eab24ca77891a9d3e8fe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_072da0e532aaabb231ee2d985dc5a4d2e5e6a387d538d0075690a6cfa1d229b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_072da0e532aaabb231ee2d985dc5a4d2e5e6a387d538d0075690a6cfa1d229b5->enter($__internal_072da0e532aaabb231ee2d985dc5a4d2e5e6a387d538d0075690a6cfa1d229b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:show.html.twig"));

        $__internal_66590547aa2b9ad558ae87daad6622b700ef0b0f7eac0ed60ec4320faa4f1425 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66590547aa2b9ad558ae87daad6622b700ef0b0f7eac0ed60ec4320faa4f1425->enter($__internal_66590547aa2b9ad558ae87daad6622b700ef0b0f7eac0ed60ec4320faa4f1425_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_072da0e532aaabb231ee2d985dc5a4d2e5e6a387d538d0075690a6cfa1d229b5->leave($__internal_072da0e532aaabb231ee2d985dc5a4d2e5e6a387d538d0075690a6cfa1d229b5_prof);

        
        $__internal_66590547aa2b9ad558ae87daad6622b700ef0b0f7eac0ed60ec4320faa4f1425->leave($__internal_66590547aa2b9ad558ae87daad6622b700ef0b0f7eac0ed60ec4320faa4f1425_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b28fc43445e488fec4789118aca47d20e681d3e9ec05960c0b62c1b049ff647a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b28fc43445e488fec4789118aca47d20e681d3e9ec05960c0b62c1b049ff647a->enter($__internal_b28fc43445e488fec4789118aca47d20e681d3e9ec05960c0b62c1b049ff647a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_741c3773072c629dd369cc78062d9f2a7d6ea303a08fa292361ce4fb3573cdbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_741c3773072c629dd369cc78062d9f2a7d6ea303a08fa292361ce4fb3573cdbf->enter($__internal_741c3773072c629dd369cc78062d9f2a7d6ea303a08fa292361ce4fb3573cdbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category</h1>
                    <table>
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()), "html", null, true);
        echo "</td>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "title", array()), "html", null, true);
        echo "</td>
                            </tr>
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            ";
        // line 29
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            ";
        // line 31
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_741c3773072c629dd369cc78062d9f2a7d6ea303a08fa292361ce4fb3573cdbf->leave($__internal_741c3773072c629dd369cc78062d9f2a7d6ea303a08fa292361ce4fb3573cdbf_prof);

        
        $__internal_b28fc43445e488fec4789118aca47d20e681d3e9ec05960c0b62c1b049ff647a->leave($__internal_b28fc43445e488fec4789118aca47d20e681d3e9ec05960c0b62c1b049ff647a_prof);

    }

    public function getTemplateName()
    {
        return ":category:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 31,  88 => 29,  82 => 26,  76 => 23,  67 => 17,  60 => 13,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category</h1>
                    <table>
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>{{ category.id }}</td>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td>{{ category.title }}</td>
                            </tr>
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"{{ path('category_edit', { 'id': category.id }) }}\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            {{ form_start(delete_form) }}
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            {{ form_end(delete_form) }}
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":category:show.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/category/show.html.twig");
    }
}
