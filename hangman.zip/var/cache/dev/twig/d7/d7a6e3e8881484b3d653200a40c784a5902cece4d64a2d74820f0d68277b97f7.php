<?php

/* :game:index.html.twig */
class __TwigTemplate_149ef673f88d7ba9c3d50323f256b9352488bc1460498eea63a84f6733da2187 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":game:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29a6010efdcf25c62c80c643ffcd41e334b96516dbb961f73dc0124bbd323ea0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29a6010efdcf25c62c80c643ffcd41e334b96516dbb961f73dc0124bbd323ea0->enter($__internal_29a6010efdcf25c62c80c643ffcd41e334b96516dbb961f73dc0124bbd323ea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:index.html.twig"));

        $__internal_2706b2dd27aeffa57989ef6734f0c3c54730a5e2e337c5369450d5c5caa36380 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2706b2dd27aeffa57989ef6734f0c3c54730a5e2e337c5369450d5c5caa36380->enter($__internal_2706b2dd27aeffa57989ef6734f0c3c54730a5e2e337c5369450d5c5caa36380_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_29a6010efdcf25c62c80c643ffcd41e334b96516dbb961f73dc0124bbd323ea0->leave($__internal_29a6010efdcf25c62c80c643ffcd41e334b96516dbb961f73dc0124bbd323ea0_prof);

        
        $__internal_2706b2dd27aeffa57989ef6734f0c3c54730a5e2e337c5369450d5c5caa36380->leave($__internal_2706b2dd27aeffa57989ef6734f0c3c54730a5e2e337c5369450d5c5caa36380_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_cec16bb0815c5509f85d7f2142e2b33dbc3e7164956d84b1ee2bb7442d9bc35d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cec16bb0815c5509f85d7f2142e2b33dbc3e7164956d84b1ee2bb7442d9bc35d->enter($__internal_cec16bb0815c5509f85d7f2142e2b33dbc3e7164956d84b1ee2bb7442d9bc35d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f763740493c8a3b092375856f95e6d1f5578039e6a0d80a01f6f2ce593af3b73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f763740493c8a3b092375856f95e6d1f5578039e6a0d80a01f6f2ce593af3b73->enter($__internal_f763740493c8a3b092375856f95e6d1f5578039e6a0d80a01f6f2ce593af3b73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">           
                <div class=\"col-xs-12 col-md-6\"> 
                    <div class=\"panel panel-primary\">
                        <div class=\"panel-heading\">
                            <h3>Guess the word</h3>
                        </div>
                        <div class=\"panel-body\">                           
                            <p class=\"attempts\">
                                <strong>Remaining attempts  <span class=\"label label-success\">";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "remainingAttempts", array()), "html", null, true);
        echo "</span> </strong>
                            </p>
                            <hr>
                             <p class=\"category\">
                                <strong>Category: </strong><span class=\"label label-default\">";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "category", array()), "html", null, true);
        echo "</span>
                            </p>
                            <hr>
                            <p class=\"hint\">
                                <strong>HINT:</strong>  <span class=\"label label-info\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "hint", array()), "html", null, true);
        echo "</span>
                            </p>     
                            <hr>
                            <ul class=\"word_letters\">
                                ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "wordLetters", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["letter"]) {
            // line 27
            echo "                                    <li class=\"letter ";
            echo (($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "isLetterFound", array(0 => $context["letter"]), "method")) ? ("guessed") : (""));
            echo "\">
                                        ";
            // line 28
            echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "isLetterFound", array(0 => $context["letter"]), "method")) ? ($context["letter"]) : ("_")), "html", null, true);
            echo "
                                    </li>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['letter'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "                            </ul>
                            <hr>
                            <p> <strong>Letters you already tried:</strong> 
                                ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "triedLetters", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["letter"]) {
            // line 35
            echo "                                    <span class=\"badge \">";
            echo twig_escape_filter($this->env, $context["letter"], "html", null, true);
            echo "</span>,
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['letter'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                            </p>
                        </div>
                    </div>
                </div>
                <div class=\"col-xs-12 col-md-6 hidden-xs\">
                    <img src=\"/img/";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "remainingAttempts", array()), "html", null, true);
        echo ".png\" alt=\"hangman\" class=\"img-responsive hangman\">
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h3>Try a letter</h3>
                    </div>
                    <div class=\"panel-body\">
                        <ul>
                            ";
        // line 54
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("try_letter")));
        echo "
                            ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
                            <input type=\"submit\" value=\"Submit\" class=\"btn btn-lg btn-primary btn-block\">
                            ";
        // line 57
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "
                            ";
        // line 58
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
                        </ul>
                    </div>
                </div>
            </div>
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\"> 
                        <h3>Try a word</h3>
                    </div>
                    <div class=\"panel-body\">
                        <ul>
                            ";
        // line 70
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["formWord"]) ? $context["formWord"] : $this->getContext($context, "formWord")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("try_word")));
        echo "
                            ";
        // line 71
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["formWord"]) ? $context["formWord"] : $this->getContext($context, "formWord")), 'widget');
        echo "
                            <input type=\"submit\" value=\"Submit\" class=\"btn btn-lg btn-primary btn-block\">
                            ";
        // line 73
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["formWord"]) ? $context["formWord"] : $this->getContext($context, "formWord")), 'rest');
        echo "
                            ";
        // line 74
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["formWord"]) ? $context["formWord"] : $this->getContext($context, "formWord")), 'form_end');
        echo "
                        </ul>
                    </div>
                </div>
            </div>
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">        
                        <h3>Reset game</h3>
                    </div>
                    <div class=\"panel-body\">
                        <a href=\"";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game_reset");
        echo "\" class=\"btn btn-lg btn-info btn-block\"><i class=\"glyphicon glyphicon-refresh\"></i>Reset the game</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_f763740493c8a3b092375856f95e6d1f5578039e6a0d80a01f6f2ce593af3b73->leave($__internal_f763740493c8a3b092375856f95e6d1f5578039e6a0d80a01f6f2ce593af3b73_prof);

        
        $__internal_cec16bb0815c5509f85d7f2142e2b33dbc3e7164956d84b1ee2bb7442d9bc35d->leave($__internal_cec16bb0815c5509f85d7f2142e2b33dbc3e7164956d84b1ee2bb7442d9bc35d_prof);

    }

    public function getTemplateName()
    {
        return ":game:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  195 => 85,  181 => 74,  177 => 73,  172 => 71,  168 => 70,  153 => 58,  149 => 57,  144 => 55,  140 => 54,  125 => 42,  118 => 37,  109 => 35,  105 => 34,  100 => 31,  91 => 28,  86 => 27,  82 => 26,  75 => 22,  68 => 18,  61 => 14,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">           
                <div class=\"col-xs-12 col-md-6\"> 
                    <div class=\"panel panel-primary\">
                        <div class=\"panel-heading\">
                            <h3>Guess the word</h3>
                        </div>
                        <div class=\"panel-body\">                           
                            <p class=\"attempts\">
                                <strong>Remaining attempts  <span class=\"label label-success\">{{ game.remainingAttempts }}</span> </strong>
                            </p>
                            <hr>
                             <p class=\"category\">
                                <strong>Category: </strong><span class=\"label label-default\">{{game.category}}</span>
                            </p>
                            <hr>
                            <p class=\"hint\">
                                <strong>HINT:</strong>  <span class=\"label label-info\">{{ game.hint }}</span>
                            </p>     
                            <hr>
                            <ul class=\"word_letters\">
                                {% for letter in game.wordLetters %}
                                    <li class=\"letter {{ game.isLetterFound(letter) ? 'guessed' : '' }}\">
                                        {{ game.isLetterFound(letter) ? letter : '_' }}
                                    </li>
                                {% endfor %}
                            </ul>
                            <hr>
                            <p> <strong>Letters you already tried:</strong> 
                                {% for letter in game.triedLetters %}
                                    <span class=\"badge \">{{ letter}}</span>,
                                {% endfor %}
                            </p>
                        </div>
                    </div>
                </div>
                <div class=\"col-xs-12 col-md-6 hidden-xs\">
                    <img src=\"/img/{{game.remainingAttempts}}.png\" alt=\"hangman\" class=\"img-responsive hangman\">
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h3>Try a letter</h3>
                    </div>
                    <div class=\"panel-body\">
                        <ul>
                            {{ form_start(form,{'action': path('try_letter')})}}
                            {{ form_widget(form) }}
                            <input type=\"submit\" value=\"Submit\" class=\"btn btn-lg btn-primary btn-block\">
                            {{ form_rest(form) }}
                            {{ form_end(form) }}
                        </ul>
                    </div>
                </div>
            </div>
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\"> 
                        <h3>Try a word</h3>
                    </div>
                    <div class=\"panel-body\">
                        <ul>
                            {{ form_start(formWord,{'action': path('try_word')})}}
                            {{ form_widget(formWord) }}
                            <input type=\"submit\" value=\"Submit\" class=\"btn btn-lg btn-primary btn-block\">
                            {{ form_rest(formWord) }}
                            {{ form_end(formWord) }}
                        </ul>
                    </div>
                </div>
            </div>
            <div class=\"col-xs-12 col-sm-4\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">        
                        <h3>Reset game</h3>
                    </div>
                    <div class=\"panel-body\">
                        <a href=\"{{ path('game_reset') }}\" class=\"btn btn-lg btn-info btn-block\"><i class=\"glyphicon glyphicon-refresh\"></i>Reset the game</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

{% endblock %}
", ":game:index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/game/index.html.twig");
    }
}
