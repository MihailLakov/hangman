<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_28af261784602a733934e4ab4f45d1ccf64fd4cc95259defed0bf2dd5cc44df5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_841c2d455cf58569a53049be053e6f33dc34e2a761801a346b1f5243cdea556e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_841c2d455cf58569a53049be053e6f33dc34e2a761801a346b1f5243cdea556e->enter($__internal_841c2d455cf58569a53049be053e6f33dc34e2a761801a346b1f5243cdea556e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_d65adcc89c1a2573816bbcc4475547f5d944a5f5ee91ae2bfce30dcfc79ae373 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d65adcc89c1a2573816bbcc4475547f5d944a5f5ee91ae2bfce30dcfc79ae373->enter($__internal_d65adcc89c1a2573816bbcc4475547f5d944a5f5ee91ae2bfce30dcfc79ae373_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_841c2d455cf58569a53049be053e6f33dc34e2a761801a346b1f5243cdea556e->leave($__internal_841c2d455cf58569a53049be053e6f33dc34e2a761801a346b1f5243cdea556e_prof);

        
        $__internal_d65adcc89c1a2573816bbcc4475547f5d944a5f5ee91ae2bfce30dcfc79ae373->leave($__internal_d65adcc89c1a2573816bbcc4475547f5d944a5f5ee91ae2bfce30dcfc79ae373_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
