<?php

/* :default:login.html.twig */
class __TwigTemplate_c666ccee4bb5139a7c5eda48c5ba2fa757f6b69c4ed9e43f845cac90b67d385c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9adf859f32be14ddc9c97bfbc328a6719b31e180874a43d03f72ddd4acd1fbe8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9adf859f32be14ddc9c97bfbc328a6719b31e180874a43d03f72ddd4acd1fbe8->enter($__internal_9adf859f32be14ddc9c97bfbc328a6719b31e180874a43d03f72ddd4acd1fbe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:login.html.twig"));

        $__internal_d436d564948e2f3473792f10235721a36168cb1c4a8b5a2f379d68405b631ff2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d436d564948e2f3473792f10235721a36168cb1c4a8b5a2f379d68405b631ff2->enter($__internal_d436d564948e2f3473792f10235721a36168cb1c4a8b5a2f379d68405b631ff2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9adf859f32be14ddc9c97bfbc328a6719b31e180874a43d03f72ddd4acd1fbe8->leave($__internal_9adf859f32be14ddc9c97bfbc328a6719b31e180874a43d03f72ddd4acd1fbe8_prof);

        
        $__internal_d436d564948e2f3473792f10235721a36168cb1c4a8b5a2f379d68405b631ff2->leave($__internal_d436d564948e2f3473792f10235721a36168cb1c4a8b5a2f379d68405b631ff2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_812804910bb465c12d9b9b4825724c99c55b1f5a527dfcf00d3f728c2265633b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_812804910bb465c12d9b9b4825724c99c55b1f5a527dfcf00d3f728c2265633b->enter($__internal_812804910bb465c12d9b9b4825724c99c55b1f5a527dfcf00d3f728c2265633b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_da26672b44e87eb7bbcb980fc5f5bfc56bf14af09019f63f55920f4a2ea6f9b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da26672b44e87eb7bbcb980fc5f5bfc56bf14af09019f63f55920f4a2ea6f9b6->enter($__internal_da26672b44e87eb7bbcb980fc5f5bfc56bf14af09019f63f55920f4a2ea6f9b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2> Please login to play Hangman! </h2>
                    <p>You can't play our awesome game without having an account</p>
                    ";
        // line 10
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 11
            echo "                        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
                    ";
        }
        // line 13
        echo "                </div>
                <div class=\"col-xs-12\">
                    <form action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-login");
        echo "\" method=\"POST\">
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Username</label>
                            <input type=\"text\" name=\"_username\" class=\"form-control\"> 
                        </div>
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Password</label>
                            <input type=\"password\" name=\"_password\" class=\"form-control\"> 
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn btn-bg btn-primary\">Login </button>
                        <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-register");
        echo "\" class=\"btn btn-info btn-bg\"> Register new account</a>
                    </form>
                </div>      
            </div>      
        </div>
    </div>
";
        
        $__internal_da26672b44e87eb7bbcb980fc5f5bfc56bf14af09019f63f55920f4a2ea6f9b6->leave($__internal_da26672b44e87eb7bbcb980fc5f5bfc56bf14af09019f63f55920f4a2ea6f9b6_prof);

        
        $__internal_812804910bb465c12d9b9b4825724c99c55b1f5a527dfcf00d3f728c2265633b->leave($__internal_812804910bb465c12d9b9b4825724c99c55b1f5a527dfcf00d3f728c2265633b_prof);

    }

    public function getTemplateName()
    {
        return ":default:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 26,  81 => 24,  69 => 15,  65 => 13,  59 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2> Please login to play Hangman! </h2>
                    <p>You can't play our awesome game without having an account</p>
                    {% if error %}
                        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
                    {% endif %}
                </div>
                <div class=\"col-xs-12\">
                    <form action=\"{{path('security-login')}}\" method=\"POST\">
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Username</label>
                            <input type=\"text\" name=\"_username\" class=\"form-control\"> 
                        </div>
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Password</label>
                            <input type=\"password\" name=\"_password\" class=\"form-control\"> 
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/>
                        <button type=\"submit\" class=\"btn btn-bg btn-primary\">Login </button>
                        <a href=\"{{path('security-register')}}\" class=\"btn btn-info btn-bg\"> Register new account</a>
                    </form>
                </div>      
            </div>      
        </div>
    </div>
{% endblock %}
", ":default:login.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/default/login.html.twig");
    }
}
