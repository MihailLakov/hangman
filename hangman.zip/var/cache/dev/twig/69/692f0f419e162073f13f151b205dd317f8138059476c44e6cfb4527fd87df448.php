<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_087bfe8cb0aab2ac0eb77069cb02f64f467d14a7b40971dc0501a522e6481bec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b142d02144d20355de42b580cb29b9821fcfa13e9a9f7dbfd51db509dc5af3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b142d02144d20355de42b580cb29b9821fcfa13e9a9f7dbfd51db509dc5af3d->enter($__internal_8b142d02144d20355de42b580cb29b9821fcfa13e9a9f7dbfd51db509dc5af3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_48436052d917c5ac2f356519b9ab528bfaefa41f98446ec8c63eb7d8a3e7db53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48436052d917c5ac2f356519b9ab528bfaefa41f98446ec8c63eb7d8a3e7db53->enter($__internal_48436052d917c5ac2f356519b9ab528bfaefa41f98446ec8c63eb7d8a3e7db53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_8b142d02144d20355de42b580cb29b9821fcfa13e9a9f7dbfd51db509dc5af3d->leave($__internal_8b142d02144d20355de42b580cb29b9821fcfa13e9a9f7dbfd51db509dc5af3d_prof);

        
        $__internal_48436052d917c5ac2f356519b9ab528bfaefa41f98446ec8c63eb7d8a3e7db53->leave($__internal_48436052d917c5ac2f356519b9ab528bfaefa41f98446ec8c63eb7d8a3e7db53_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
