<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_f91fbb8aaac3002b64d563a9116cc2b5dc907d03c2cc7ebd064d633d3bfe12ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68b540da6983bff6283727d091690fa660921b40895755b5aebc81c86b4b55a0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68b540da6983bff6283727d091690fa660921b40895755b5aebc81c86b4b55a0->enter($__internal_68b540da6983bff6283727d091690fa660921b40895755b5aebc81c86b4b55a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_5f66338e4409ec26e1732f05865f85e922fe17c06499eb760cfc3ea7a3f5d623 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f66338e4409ec26e1732f05865f85e922fe17c06499eb760cfc3ea7a3f5d623->enter($__internal_5f66338e4409ec26e1732f05865f85e922fe17c06499eb760cfc3ea7a3f5d623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_68b540da6983bff6283727d091690fa660921b40895755b5aebc81c86b4b55a0->leave($__internal_68b540da6983bff6283727d091690fa660921b40895755b5aebc81c86b4b55a0_prof);

        
        $__internal_5f66338e4409ec26e1732f05865f85e922fe17c06499eb760cfc3ea7a3f5d623->leave($__internal_5f66338e4409ec26e1732f05865f85e922fe17c06499eb760cfc3ea7a3f5d623_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
