<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_59b195687fbb6d5c0b89a3a56b8156ebb321b3f6445f70223726cd6d13fd32f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05f2ce391eb21dd23930638b2b3eab4b90be6bd6bf38ef546e0bcd7057e7d8f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05f2ce391eb21dd23930638b2b3eab4b90be6bd6bf38ef546e0bcd7057e7d8f9->enter($__internal_05f2ce391eb21dd23930638b2b3eab4b90be6bd6bf38ef546e0bcd7057e7d8f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_571eb9b1293367413c8332cfe4119844d6636f2eed4dddd26e776d62a58a65a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_571eb9b1293367413c8332cfe4119844d6636f2eed4dddd26e776d62a58a65a1->enter($__internal_571eb9b1293367413c8332cfe4119844d6636f2eed4dddd26e776d62a58a65a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_05f2ce391eb21dd23930638b2b3eab4b90be6bd6bf38ef546e0bcd7057e7d8f9->leave($__internal_05f2ce391eb21dd23930638b2b3eab4b90be6bd6bf38ef546e0bcd7057e7d8f9_prof);

        
        $__internal_571eb9b1293367413c8332cfe4119844d6636f2eed4dddd26e776d62a58a65a1->leave($__internal_571eb9b1293367413c8332cfe4119844d6636f2eed4dddd26e776d62a58a65a1_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_f111543a5ee220b44524aac3977efc8938c0bed3a5044ba41703953d8272c462 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f111543a5ee220b44524aac3977efc8938c0bed3a5044ba41703953d8272c462->enter($__internal_f111543a5ee220b44524aac3977efc8938c0bed3a5044ba41703953d8272c462_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_da2e6be1f3aafcc0eff297605c845259925234b23ee7c04ff8cfe4a732f16ea8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da2e6be1f3aafcc0eff297605c845259925234b23ee7c04ff8cfe4a732f16ea8->enter($__internal_da2e6be1f3aafcc0eff297605c845259925234b23ee7c04ff8cfe4a732f16ea8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_da2e6be1f3aafcc0eff297605c845259925234b23ee7c04ff8cfe4a732f16ea8->leave($__internal_da2e6be1f3aafcc0eff297605c845259925234b23ee7c04ff8cfe4a732f16ea8_prof);

        
        $__internal_f111543a5ee220b44524aac3977efc8938c0bed3a5044ba41703953d8272c462->leave($__internal_f111543a5ee220b44524aac3977efc8938c0bed3a5044ba41703953d8272c462_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
