<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_12fdd4c9b3a9cdf5a05eb719944fbacef76a4d3f7e2592c025dda7a70dda8bac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be3c9b8b42651e6e56b81f09891036a0e2e64c2bd181fb6f93da96456f43e4b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be3c9b8b42651e6e56b81f09891036a0e2e64c2bd181fb6f93da96456f43e4b6->enter($__internal_be3c9b8b42651e6e56b81f09891036a0e2e64c2bd181fb6f93da96456f43e4b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_dba9d875610fcb7c791bc2e354174b64c6fb25b1f88cdf504332d7454e38ac9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dba9d875610fcb7c791bc2e354174b64c6fb25b1f88cdf504332d7454e38ac9a->enter($__internal_dba9d875610fcb7c791bc2e354174b64c6fb25b1f88cdf504332d7454e38ac9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_be3c9b8b42651e6e56b81f09891036a0e2e64c2bd181fb6f93da96456f43e4b6->leave($__internal_be3c9b8b42651e6e56b81f09891036a0e2e64c2bd181fb6f93da96456f43e4b6_prof);

        
        $__internal_dba9d875610fcb7c791bc2e354174b64c6fb25b1f88cdf504332d7454e38ac9a->leave($__internal_dba9d875610fcb7c791bc2e354174b64c6fb25b1f88cdf504332d7454e38ac9a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
