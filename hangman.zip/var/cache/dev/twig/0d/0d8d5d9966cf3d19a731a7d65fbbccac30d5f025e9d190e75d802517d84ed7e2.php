<?php

/* word/new.html.twig */
class __TwigTemplate_06f35ae3c57d9c6d97ca309f38ab8aab4f8470f39f9be1a4cc9a414ff665a690 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "word/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3bb31c2fcaebdb074c32ebcc39266d0a2ff9ae06025383953ce277dd8374f14b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3bb31c2fcaebdb074c32ebcc39266d0a2ff9ae06025383953ce277dd8374f14b->enter($__internal_3bb31c2fcaebdb074c32ebcc39266d0a2ff9ae06025383953ce277dd8374f14b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/new.html.twig"));

        $__internal_139579b4062d96020fb1582341d5011ab865d902ac5185b522f374d26a3b1940 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_139579b4062d96020fb1582341d5011ab865d902ac5185b522f374d26a3b1940->enter($__internal_139579b4062d96020fb1582341d5011ab865d902ac5185b522f374d26a3b1940_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3bb31c2fcaebdb074c32ebcc39266d0a2ff9ae06025383953ce277dd8374f14b->leave($__internal_3bb31c2fcaebdb074c32ebcc39266d0a2ff9ae06025383953ce277dd8374f14b_prof);

        
        $__internal_139579b4062d96020fb1582341d5011ab865d902ac5185b522f374d26a3b1940->leave($__internal_139579b4062d96020fb1582341d5011ab865d902ac5185b522f374d26a3b1940_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_21bfb278fa839701fb164469d8d41350d2640b31c49d80cc06728dc64fb3ed79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21bfb278fa839701fb164469d8d41350d2640b31c49d80cc06728dc64fb3ed79->enter($__internal_21bfb278fa839701fb164469d8d41350d2640b31c49d80cc06728dc64fb3ed79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_865f84b4f119bda3066358ad2324a49a66f3dfb5d54bb20c17e2edc996472776 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_865f84b4f119bda3066358ad2324a49a66f3dfb5d54bb20c17e2edc996472776->enter($__internal_865f84b4f119bda3066358ad2324a49a66f3dfb5d54bb20c17e2edc996472776_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word creation</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\" />
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_865f84b4f119bda3066358ad2324a49a66f3dfb5d54bb20c17e2edc996472776->leave($__internal_865f84b4f119bda3066358ad2324a49a66f3dfb5d54bb20c17e2edc996472776_prof);

        
        $__internal_21bfb278fa839701fb164469d8d41350d2640b31c49d80cc06728dc64fb3ed79->leave($__internal_21bfb278fa839701fb164469d8d41350d2640b31c49d80cc06728dc64fb3ed79_prof);

    }

    public function getTemplateName()
    {
        return "word/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word creation</h1>

                    {{ form_start(form) }}
                    {{ form_widget(form) }}
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\" />
                    {{ form_end(form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('word_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "word/new.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\word\\new.html.twig");
    }
}
