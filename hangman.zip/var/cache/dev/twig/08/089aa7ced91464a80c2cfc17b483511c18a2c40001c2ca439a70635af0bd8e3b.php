<?php

/* game/won.html.twig */
class __TwigTemplate_121a4d0dd89e9d01d25f7a5b12cdc811522c4c1a4d3c00e0b505cd66b74c2e69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "game/won.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5d5c55e329bf2bb7acf6cfc1eae1edeb028ae22d7ef2c06f51a2fbdfb53d9fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5d5c55e329bf2bb7acf6cfc1eae1edeb028ae22d7ef2c06f51a2fbdfb53d9fc->enter($__internal_e5d5c55e329bf2bb7acf6cfc1eae1edeb028ae22d7ef2c06f51a2fbdfb53d9fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/won.html.twig"));

        $__internal_2bf01cb23ea9fd4b634b3820df0dd89b2f03598625e969718a9e51ef313c5037 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2bf01cb23ea9fd4b634b3820df0dd89b2f03598625e969718a9e51ef313c5037->enter($__internal_2bf01cb23ea9fd4b634b3820df0dd89b2f03598625e969718a9e51ef313c5037_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/won.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e5d5c55e329bf2bb7acf6cfc1eae1edeb028ae22d7ef2c06f51a2fbdfb53d9fc->leave($__internal_e5d5c55e329bf2bb7acf6cfc1eae1edeb028ae22d7ef2c06f51a2fbdfb53d9fc_prof);

        
        $__internal_2bf01cb23ea9fd4b634b3820df0dd89b2f03598625e969718a9e51ef313c5037->leave($__internal_2bf01cb23ea9fd4b634b3820df0dd89b2f03598625e969718a9e51ef313c5037_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e1557ddda8c8169660be54d6c26e6d095dab88fe96395d574d483f626e3b4bef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1557ddda8c8169660be54d6c26e6d095dab88fe96395d574d483f626e3b4bef->enter($__internal_e1557ddda8c8169660be54d6c26e6d095dab88fe96395d574d483f626e3b4bef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_58b412af025402c25eeaed9e439be0962ece58a190374181afc3f1460fee16c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58b412af025402c25eeaed9e439be0962ece58a190374181afc3f1460fee16c8->enter($__internal_58b412af025402c25eeaed9e439be0962ece58a190374181afc3f1460fee16c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <div class=\"jumbotron\">
                <h2 class=\"success\">
                    Congratulations the word was <strong>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "html", null, true);
        echo "</strong> and you guessed it correctly!
                </h2>              
              
                    <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game_reset");
        echo "\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_58b412af025402c25eeaed9e439be0962ece58a190374181afc3f1460fee16c8->leave($__internal_58b412af025402c25eeaed9e439be0962ece58a190374181afc3f1460fee16c8_prof);

        
        $__internal_e1557ddda8c8169660be54d6c26e6d095dab88fe96395d574d483f626e3b4bef->leave($__internal_e1557ddda8c8169660be54d6c26e6d095dab88fe96395d574d483f626e3b4bef_prof);

    }

    public function getTemplateName()
    {
        return "game/won.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 11,  56 => 8,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <div class=\"jumbotron\">
                <h2 class=\"success\">
                    Congratulations the word was <strong>{{ word }}</strong> and you guessed it correctly!
                </h2>              
              
                    <a href=\"{{ path('game_reset')}}\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "game/won.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\game\\won.html.twig");
    }
}
