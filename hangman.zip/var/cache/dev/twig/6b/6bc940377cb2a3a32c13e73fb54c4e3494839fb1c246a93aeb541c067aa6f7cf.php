<?php

/* :game:statistics.html.twig */
class __TwigTemplate_fc74c00ac19954624f26d6ceb152776ac548cd303f3c3276d4cf61352c6c0315 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":game:statistics.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d127c34a54be0401a70048b00db6ec5e696264864358db11bec7e0aab4a210ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d127c34a54be0401a70048b00db6ec5e696264864358db11bec7e0aab4a210ab->enter($__internal_d127c34a54be0401a70048b00db6ec5e696264864358db11bec7e0aab4a210ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:statistics.html.twig"));

        $__internal_ee94aef437f1ef7939fa5638acb9dd18b2bae7f41f90575beb3811345495063e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee94aef437f1ef7939fa5638acb9dd18b2bae7f41f90575beb3811345495063e->enter($__internal_ee94aef437f1ef7939fa5638acb9dd18b2bae7f41f90575beb3811345495063e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:statistics.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d127c34a54be0401a70048b00db6ec5e696264864358db11bec7e0aab4a210ab->leave($__internal_d127c34a54be0401a70048b00db6ec5e696264864358db11bec7e0aab4a210ab_prof);

        
        $__internal_ee94aef437f1ef7939fa5638acb9dd18b2bae7f41f90575beb3811345495063e->leave($__internal_ee94aef437f1ef7939fa5638acb9dd18b2bae7f41f90575beb3811345495063e_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_f56ab36a485757ddf16dcf7c0d5a9eea04e14685cecf4b80224f7e68a9815fd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f56ab36a485757ddf16dcf7c0d5a9eea04e14685cecf4b80224f7e68a9815fd0->enter($__internal_f56ab36a485757ddf16dcf7c0d5a9eea04e14685cecf4b80224f7e68a9815fd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4fb7f14870c34ca811534eb9c9f83e03e0fa8405f7b1062c97fee082c59b5323 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fb7f14870c34ca811534eb9c9f83e03e0fa8405f7b1062c97fee082c59b5323->enter($__internal_4fb7f14870c34ca811534eb9c9f83e03e0fa8405f7b1062c97fee082c59b5323_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2>
                        Your game statistics
                    </h2> 
                </div>
                <div class=\"col-xs-12\">
                    <table class=\"table table-striped table-bordered\">
                        <tr>
                            <th>Games played</th>
                            <th>Games won</th>
                            <th>Games lost</th>
                            <th>Letters tried</th>
                            <th>Whole words gussed</th>
                        </tr>                        
                        <tr class=\"info\">
                            <td>";
        // line 21
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesPlayed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesPlayed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
        }
        echo "</td>
                            <td>";
        // line 22
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesWon", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesWon", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 23
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesLost", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesLost", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 24
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "LettersGuessed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "LettersGuessed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 25
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "WholeWordsGuessed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "WholeWordsGuessed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_4fb7f14870c34ca811534eb9c9f83e03e0fa8405f7b1062c97fee082c59b5323->leave($__internal_4fb7f14870c34ca811534eb9c9f83e03e0fa8405f7b1062c97fee082c59b5323_prof);

        
        $__internal_f56ab36a485757ddf16dcf7c0d5a9eea04e14685cecf4b80224f7e68a9815fd0->leave($__internal_f56ab36a485757ddf16dcf7c0d5a9eea04e14685cecf4b80224f7e68a9815fd0_prof);

    }

    public function getTemplateName()
    {
        return ":game:statistics.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 25,  104 => 24,  92 => 23,  80 => 22,  69 => 21,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2>
                        Your game statistics
                    </h2> 
                </div>
                <div class=\"col-xs-12\">
                    <table class=\"table table-striped table-bordered\">
                        <tr>
                            <th>Games played</th>
                            <th>Games won</th>
                            <th>Games lost</th>
                            <th>Letters tried</th>
                            <th>Whole words gussed</th>
                        </tr>                        
                        <tr class=\"info\">
                            <td>{% if stats.GamesPlayed %} {{ stats.GamesPlayed }} {% else %} {{ 0 }}{% endif %}</td>
                            <td>{% if stats.GamesWon %} {{ stats.GamesWon }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.GamesLost %} {{ stats.GamesLost }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.LettersGuessed %} {{ stats.LettersGuessed }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.WholeWordsGuessed %} {{ stats.WholeWordsGuessed }} {% else %} {{ 0 }} {% endif %}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":game:statistics.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/game/statistics.html.twig");
    }
}
