<?php

/* header.html.twig */
class __TwigTemplate_2a45c7f8e315195ad9405e3b15fcc30cc3cb40b9b0ed8a13bcd31b5da5105193 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f285c5a75d48c9b9d43dcaa326767cbbcc643be84bcf811591a2568497c846b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f285c5a75d48c9b9d43dcaa326767cbbcc643be84bcf811591a2568497c846b->enter($__internal_2f285c5a75d48c9b9d43dcaa326767cbbcc643be84bcf811591a2568497c846b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "header.html.twig"));

        $__internal_1a086150ead9cfa1ec8bb51a33509c055182ab8fa4a9a412ef2915fa2db21659 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a086150ead9cfa1ec8bb51a33509c055182ab8fa4a9a412ef2915fa2db21659->enter($__internal_1a086150ead9cfa1ec8bb51a33509c055182ab8fa4a9a412ef2915fa2db21659_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "header.html.twig"));

        // line 1
        echo "<header id=\"home\">     
    <div class=\"container\">
        <div class=\"row\">
            <nav class=\"navbar navbar-default\">                    
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button> 
                    <h1 class=\"navbar-brand\" id=\"logo\">
                        <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\"><img src=\"/img/logo.png\" class=\"img-responsive\"></a>
                    </h1>
                </div>           
                <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                    <ul class=\"nav navbar-nav\"> 
                        <li><a href=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game");
        echo "\">Play</a></li>
                        <li><a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-login");
        echo "\">Login</a></li>
                        <li><a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-register");
        echo "\">Register</a></li>   
                        <li><a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("statistics");
        echo "\">Statistics</a></li>  
                        ";
        // line 22
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 23
            echo "                            <li>
                                <a href=\"";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin-homepage");
            echo "\">Admin Panel</a>
                            </li>
                            <li>
                                <a href=\"";
            // line 27
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-logout");
            echo "\">Logout</a>
                            </li>
                        ";
        }
        // line 30
        echo "                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-xs-12\">
            <div class=\"notifications\">  
                ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 41
            echo "                    <div class=\"alert alert-danger\" role=\"alert\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 44
            echo "                    <div class=\"alert alert-success\" role=\"alert\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 47
            echo "                    <div class=\"alert alert-info\" role=\"alert\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "warning"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 50
            echo "                    <div class=\"alert alert-warning\" role=\"alert\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "   
            </div>
        </div>
    </div>
</div>";
        
        $__internal_2f285c5a75d48c9b9d43dcaa326767cbbcc643be84bcf811591a2568497c846b->leave($__internal_2f285c5a75d48c9b9d43dcaa326767cbbcc643be84bcf811591a2568497c846b_prof);

        
        $__internal_1a086150ead9cfa1ec8bb51a33509c055182ab8fa4a9a412ef2915fa2db21659->leave($__internal_1a086150ead9cfa1ec8bb51a33509c055182ab8fa4a9a412ef2915fa2db21659_prof);

    }

    public function getTemplateName()
    {
        return "header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 51,  138 => 50,  133 => 49,  124 => 47,  119 => 46,  110 => 44,  105 => 43,  96 => 41,  92 => 40,  80 => 30,  74 => 27,  68 => 24,  65 => 23,  63 => 22,  59 => 21,  55 => 20,  51 => 19,  47 => 18,  39 => 13,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<header id=\"home\">     
    <div class=\"container\">
        <div class=\"row\">
            <nav class=\"navbar navbar-default\">                    
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button> 
                    <h1 class=\"navbar-brand\" id=\"logo\">
                        <a href=\"{{path('homepage')}}\"><img src=\"/img/logo.png\" class=\"img-responsive\"></a>
                    </h1>
                </div>           
                <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                    <ul class=\"nav navbar-nav\"> 
                        <li><a href=\"{{path('game')}}\">Play</a></li>
                        <li><a href=\"{{path('security-login')}}\">Login</a></li>
                        <li><a href=\"{{path('security-register')}}\">Register</a></li>   
                        <li><a href=\"{{path('statistics')}}\">Statistics</a></li>  
                        {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                            <li>
                                <a href=\"{{path('admin-homepage')}}\">Admin Panel</a>
                            </li>
                            <li>
                                <a href=\"{{path('security-logout')}}\">Logout</a>
                            </li>
                        {%endif%}
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-xs-12\">
            <div class=\"notifications\">  
                {% for flashMessage in app.session.flashbag.get('error') %}
                    <div class=\"alert alert-danger\" role=\"alert\">{{ flashMessage }}</div>
                {% endfor %}
                {% for flashMessage in app.session.flashbag.get('success') %}
                    <div class=\"alert alert-success\" role=\"alert\">{{ flashMessage }}</div>
                {% endfor %}
                {% for flashMessage in app.session.flashbag.get('info') %}
                    <div class=\"alert alert-info\" role=\"alert\">{{ flashMessage }}</div>
                {% endfor %}
                {% for flashMessage in app.session.flashbag.get('warning') %}
                    <div class=\"alert alert-warning\" role=\"alert\">{{ flashMessage }}</div>
                {% endfor %}   
            </div>
        </div>
    </div>
</div>", "header.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\header.html.twig");
    }
}
