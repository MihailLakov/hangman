<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_0082082c1bc9fb0dec011fb60d7621f79315ff8bdc171c27c5b4dc8bfc64e5b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b965be67aa14d1f6aef6473bdbd1b37375bc47d1d0e06269a77c92b294027d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b965be67aa14d1f6aef6473bdbd1b37375bc47d1d0e06269a77c92b294027d7->enter($__internal_3b965be67aa14d1f6aef6473bdbd1b37375bc47d1d0e06269a77c92b294027d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_b70fca67c1c85879c59b0531bb0fad8e276cd2e4c3fc975b0af850bd6e817cf9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b70fca67c1c85879c59b0531bb0fad8e276cd2e4c3fc975b0af850bd6e817cf9->enter($__internal_b70fca67c1c85879c59b0531bb0fad8e276cd2e4c3fc975b0af850bd6e817cf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_3b965be67aa14d1f6aef6473bdbd1b37375bc47d1d0e06269a77c92b294027d7->leave($__internal_3b965be67aa14d1f6aef6473bdbd1b37375bc47d1d0e06269a77c92b294027d7_prof);

        
        $__internal_b70fca67c1c85879c59b0531bb0fad8e276cd2e4c3fc975b0af850bd6e817cf9->leave($__internal_b70fca67c1c85879c59b0531bb0fad8e276cd2e4c3fc975b0af850bd6e817cf9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
