<?php

/* word/edit.html.twig */
class __TwigTemplate_e7a3bbe63ca040fc00c6002c3b394ab219a4bf38fe60efb1989305d85b3008a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "word/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_938114a40f7d4152bd37af39c94af8082ee30ef4961ade49a94561011a9a4e79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_938114a40f7d4152bd37af39c94af8082ee30ef4961ade49a94561011a9a4e79->enter($__internal_938114a40f7d4152bd37af39c94af8082ee30ef4961ade49a94561011a9a4e79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/edit.html.twig"));

        $__internal_5a949a3c39eb544db2a2494457cfba50e70075ec89d29e8d275062eb8ebb8246 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a949a3c39eb544db2a2494457cfba50e70075ec89d29e8d275062eb8ebb8246->enter($__internal_5a949a3c39eb544db2a2494457cfba50e70075ec89d29e8d275062eb8ebb8246_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_938114a40f7d4152bd37af39c94af8082ee30ef4961ade49a94561011a9a4e79->leave($__internal_938114a40f7d4152bd37af39c94af8082ee30ef4961ade49a94561011a9a4e79_prof);

        
        $__internal_5a949a3c39eb544db2a2494457cfba50e70075ec89d29e8d275062eb8ebb8246->leave($__internal_5a949a3c39eb544db2a2494457cfba50e70075ec89d29e8d275062eb8ebb8246_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_342bf8cccce578f4388617e554a71726c87543d33fe9ab5d04a2549869fa0ef7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_342bf8cccce578f4388617e554a71726c87543d33fe9ab5d04a2549869fa0ef7->enter($__internal_342bf8cccce578f4388617e554a71726c87543d33fe9ab5d04a2549869fa0ef7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c72b3d01fb3d04319147588ce604baa1c8c08b286dd0323805908f62b1f243a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c72b3d01fb3d04319147588ce604baa1c8c08b286dd0323805908f62b1f243a8->enter($__internal_c72b3d01fb3d04319147588ce604baa1c8c08b286dd0323805908f62b1f243a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word edit</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Edit\" class=\"btn btn-primary\"/>
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            ";
        // line 22
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_c72b3d01fb3d04319147588ce604baa1c8c08b286dd0323805908f62b1f243a8->leave($__internal_c72b3d01fb3d04319147588ce604baa1c8c08b286dd0323805908f62b1f243a8_prof);

        
        $__internal_342bf8cccce578f4388617e554a71726c87543d33fe9ab5d04a2549869fa0ef7->leave($__internal_342bf8cccce578f4388617e554a71726c87543d33fe9ab5d04a2549869fa0ef7_prof);

    }

    public function getTemplateName()
    {
        return "word/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 22,  79 => 20,  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word edit</h1>

                    {{ form_start(edit_form) }}
                    {{ form_widget(edit_form) }}
                    <input type=\"submit\" value=\"Edit\" class=\"btn btn-primary\"/>
                    {{ form_end(edit_form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('word_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            {{ form_start(delete_form) }}
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            {{ form_end(delete_form) }}
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "word/edit.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\word\\edit.html.twig");
    }
}
