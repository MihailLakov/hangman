<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_7123cc090c6ce378397a9994e45051fda49b8646d2fb30697ce7be617ad5ae3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6cd9742bbdb1251741364939c3f101fd3e97ee2e60585f83052a89623e24cf88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cd9742bbdb1251741364939c3f101fd3e97ee2e60585f83052a89623e24cf88->enter($__internal_6cd9742bbdb1251741364939c3f101fd3e97ee2e60585f83052a89623e24cf88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_b3695732ec23319a9776c6db4283fa2bab8c51eca210af7d5df06375d80fdbe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3695732ec23319a9776c6db4283fa2bab8c51eca210af7d5df06375d80fdbe1->enter($__internal_b3695732ec23319a9776c6db4283fa2bab8c51eca210af7d5df06375d80fdbe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_6cd9742bbdb1251741364939c3f101fd3e97ee2e60585f83052a89623e24cf88->leave($__internal_6cd9742bbdb1251741364939c3f101fd3e97ee2e60585f83052a89623e24cf88_prof);

        
        $__internal_b3695732ec23319a9776c6db4283fa2bab8c51eca210af7d5df06375d80fdbe1->leave($__internal_b3695732ec23319a9776c6db4283fa2bab8c51eca210af7d5df06375d80fdbe1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
