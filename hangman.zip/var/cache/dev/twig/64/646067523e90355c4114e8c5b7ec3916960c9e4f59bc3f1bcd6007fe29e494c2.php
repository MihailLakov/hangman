<?php

/* category/index.html.twig */
class __TwigTemplate_736bff0db358309e9f43b9833bed7d3e78fb3cc3133c9282b17a0b89d44c21ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_082bc3748f5b0653fed540e71f15c1028fbbdb45ce9183d33c4505315ccb282b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_082bc3748f5b0653fed540e71f15c1028fbbdb45ce9183d33c4505315ccb282b->enter($__internal_082bc3748f5b0653fed540e71f15c1028fbbdb45ce9183d33c4505315ccb282b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $__internal_8caa4f2f2240edd4ff0b0c721b702a5c3c1452d20841a6d19e57cd0ccad375d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8caa4f2f2240edd4ff0b0c721b702a5c3c1452d20841a6d19e57cd0ccad375d3->enter($__internal_8caa4f2f2240edd4ff0b0c721b702a5c3c1452d20841a6d19e57cd0ccad375d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_082bc3748f5b0653fed540e71f15c1028fbbdb45ce9183d33c4505315ccb282b->leave($__internal_082bc3748f5b0653fed540e71f15c1028fbbdb45ce9183d33c4505315ccb282b_prof);

        
        $__internal_8caa4f2f2240edd4ff0b0c721b702a5c3c1452d20841a6d19e57cd0ccad375d3->leave($__internal_8caa4f2f2240edd4ff0b0c721b702a5c3c1452d20841a6d19e57cd0ccad375d3_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_599f334b9577ebf834cdd4626d8494ec5c4479301cac569330627416125b6f1e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_599f334b9577ebf834cdd4626d8494ec5c4479301cac569330627416125b6f1e->enter($__internal_599f334b9577ebf834cdd4626d8494ec5c4479301cac569330627416125b6f1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_dc79643cf8f3c61025ea76fd37c2664dc918b0dee07a8a699b2532d9f564415e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc79643cf8f3c61025ea76fd37c2664dc918b0dee07a8a699b2532d9f564415e->enter($__internal_dc79643cf8f3c61025ea76fd37c2664dc918b0dee07a8a699b2532d9f564415e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Categories list</h1>
                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 19
            echo "                                <tr>
                                    <td><a href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
            echo "</a></td>
                                    <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "title", array()), "html", null, true);
            echo "</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-info\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_new");
        echo "\" class=\"btn btn-primary\">Create a new category</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_dc79643cf8f3c61025ea76fd37c2664dc918b0dee07a8a699b2532d9f564415e->leave($__internal_dc79643cf8f3c61025ea76fd37c2664dc918b0dee07a8a699b2532d9f564415e_prof);

        
        $__internal_599f334b9577ebf834cdd4626d8494ec5c4479301cac569330627416125b6f1e->leave($__internal_599f334b9577ebf834cdd4626d8494ec5c4479301cac569330627416125b6f1e_prof);

    }

    public function getTemplateName()
    {
        return "category/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 38,  103 => 34,  91 => 28,  85 => 25,  78 => 21,  72 => 20,  69 => 19,  65 => 18,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Categories list</h1>
                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for category in categories %}
                                <tr>
                                    <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                                    <td>{{ category.title }}</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"{{ path('category_show', { 'id': category.id }) }}\" class=\"btn btn-info\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"{{ path('category_edit', { 'id': category.id }) }}\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_new') }}\" class=\"btn btn-primary\">Create a new category</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "category/index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\category\\index.html.twig");
    }
}
