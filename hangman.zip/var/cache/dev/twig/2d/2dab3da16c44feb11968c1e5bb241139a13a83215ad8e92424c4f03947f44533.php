<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_6e4d89314752a173849abb5847f691a366e893444c7161b3f1b6c502680dd908 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcbf0d671f05c36bd00039f0e10ce53ca9cea58b0454f8599db565e02d5a1013 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcbf0d671f05c36bd00039f0e10ce53ca9cea58b0454f8599db565e02d5a1013->enter($__internal_fcbf0d671f05c36bd00039f0e10ce53ca9cea58b0454f8599db565e02d5a1013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_56079a2e2fdf8bd6c1423da73aa0a52b0554fd8e5fa2ec0fdf8171fe9051759f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56079a2e2fdf8bd6c1423da73aa0a52b0554fd8e5fa2ec0fdf8171fe9051759f->enter($__internal_56079a2e2fdf8bd6c1423da73aa0a52b0554fd8e5fa2ec0fdf8171fe9051759f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_fcbf0d671f05c36bd00039f0e10ce53ca9cea58b0454f8599db565e02d5a1013->leave($__internal_fcbf0d671f05c36bd00039f0e10ce53ca9cea58b0454f8599db565e02d5a1013_prof);

        
        $__internal_56079a2e2fdf8bd6c1423da73aa0a52b0554fd8e5fa2ec0fdf8171fe9051759f->leave($__internal_56079a2e2fdf8bd6c1423da73aa0a52b0554fd8e5fa2ec0fdf8171fe9051759f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
