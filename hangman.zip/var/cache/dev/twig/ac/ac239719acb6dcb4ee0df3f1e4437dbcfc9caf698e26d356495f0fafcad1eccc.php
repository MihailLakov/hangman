<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_0401a279fd24945d9fc83bf665faf72fd4810d06350e6175af0bf61165834f89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_690c9ee9f0dc5a821ba57a43de30a97274de686ef0465e187166f3ed6a9faaa6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_690c9ee9f0dc5a821ba57a43de30a97274de686ef0465e187166f3ed6a9faaa6->enter($__internal_690c9ee9f0dc5a821ba57a43de30a97274de686ef0465e187166f3ed6a9faaa6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_23af832551216ee165a02d5fab6dddf393b553833372488572c9b742a714c77a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23af832551216ee165a02d5fab6dddf393b553833372488572c9b742a714c77a->enter($__internal_23af832551216ee165a02d5fab6dddf393b553833372488572c9b742a714c77a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_690c9ee9f0dc5a821ba57a43de30a97274de686ef0465e187166f3ed6a9faaa6->leave($__internal_690c9ee9f0dc5a821ba57a43de30a97274de686ef0465e187166f3ed6a9faaa6_prof);

        
        $__internal_23af832551216ee165a02d5fab6dddf393b553833372488572c9b742a714c77a->leave($__internal_23af832551216ee165a02d5fab6dddf393b553833372488572c9b742a714c77a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
