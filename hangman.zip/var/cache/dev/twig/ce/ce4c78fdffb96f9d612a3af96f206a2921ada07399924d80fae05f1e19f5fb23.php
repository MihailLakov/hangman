<?php

/* game/statistics.html.twig */
class __TwigTemplate_995f0b6cf67aa6ec189eda30c50f7095387feab7cd214416535327312564bc36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "game/statistics.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a369f3a1a031396084be21e78447f659ea0c5f30c4b192039db2c6e1ef1b14fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a369f3a1a031396084be21e78447f659ea0c5f30c4b192039db2c6e1ef1b14fc->enter($__internal_a369f3a1a031396084be21e78447f659ea0c5f30c4b192039db2c6e1ef1b14fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/statistics.html.twig"));

        $__internal_7b4c5c6adce082c5a11233254b85a09e58bf9bf4fb43bee82663a101f86a558e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b4c5c6adce082c5a11233254b85a09e58bf9bf4fb43bee82663a101f86a558e->enter($__internal_7b4c5c6adce082c5a11233254b85a09e58bf9bf4fb43bee82663a101f86a558e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/statistics.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a369f3a1a031396084be21e78447f659ea0c5f30c4b192039db2c6e1ef1b14fc->leave($__internal_a369f3a1a031396084be21e78447f659ea0c5f30c4b192039db2c6e1ef1b14fc_prof);

        
        $__internal_7b4c5c6adce082c5a11233254b85a09e58bf9bf4fb43bee82663a101f86a558e->leave($__internal_7b4c5c6adce082c5a11233254b85a09e58bf9bf4fb43bee82663a101f86a558e_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_a030c048b827093c9eb20abb68ed40794d76d52cbab7e6a88272c4d59a579cc2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a030c048b827093c9eb20abb68ed40794d76d52cbab7e6a88272c4d59a579cc2->enter($__internal_a030c048b827093c9eb20abb68ed40794d76d52cbab7e6a88272c4d59a579cc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2a3c3be00910a1aa3680cef2c621a9a99e3e2f62beccef7feb2de82d8de000a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a3c3be00910a1aa3680cef2c621a9a99e3e2f62beccef7feb2de82d8de000a0->enter($__internal_2a3c3be00910a1aa3680cef2c621a9a99e3e2f62beccef7feb2de82d8de000a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2>
                        Your game statistics
                    </h2> 
                </div>
                <div class=\"col-xs-12\">
                    <table class=\"table table-striped table-bordered\">
                        <tr>
                            <th>Games played</th>
                            <th>Games won</th>
                            <th>Games lost</th>
                            <th>Letters tried</th>
                            <th>Whole words gussed</th>
                        </tr>                        
                        <tr class=\"info\">
                            <td>";
        // line 21
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesPlayed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesPlayed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
        }
        echo "</td>
                            <td>";
        // line 22
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesWon", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesWon", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 23
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesLost", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "GamesLost", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 24
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "LettersGuessed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "LettersGuessed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                            <td>";
        // line 25
        if ($this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "WholeWordsGuessed", array())) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["stats"]) ? $context["stats"] : $this->getContext($context, "stats")), "WholeWordsGuessed", array()), "html", null, true);
            echo " ";
        } else {
            echo " ";
            echo 0;
            echo " ";
        }
        echo "</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_2a3c3be00910a1aa3680cef2c621a9a99e3e2f62beccef7feb2de82d8de000a0->leave($__internal_2a3c3be00910a1aa3680cef2c621a9a99e3e2f62beccef7feb2de82d8de000a0_prof);

        
        $__internal_a030c048b827093c9eb20abb68ed40794d76d52cbab7e6a88272c4d59a579cc2->leave($__internal_a030c048b827093c9eb20abb68ed40794d76d52cbab7e6a88272c4d59a579cc2_prof);

    }

    public function getTemplateName()
    {
        return "game/statistics.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 25,  104 => 24,  92 => 23,  80 => 22,  69 => 21,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2>
                        Your game statistics
                    </h2> 
                </div>
                <div class=\"col-xs-12\">
                    <table class=\"table table-striped table-bordered\">
                        <tr>
                            <th>Games played</th>
                            <th>Games won</th>
                            <th>Games lost</th>
                            <th>Letters tried</th>
                            <th>Whole words gussed</th>
                        </tr>                        
                        <tr class=\"info\">
                            <td>{% if stats.GamesPlayed %} {{ stats.GamesPlayed }} {% else %} {{ 0 }}{% endif %}</td>
                            <td>{% if stats.GamesWon %} {{ stats.GamesWon }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.GamesLost %} {{ stats.GamesLost }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.LettersGuessed %} {{ stats.LettersGuessed }} {% else %} {{ 0 }} {% endif %}</td>
                            <td>{% if stats.WholeWordsGuessed %} {{ stats.WholeWordsGuessed }} {% else %} {{ 0 }} {% endif %}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "game/statistics.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\game\\statistics.html.twig");
    }
}
