<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_0f4745c1714d5cfd72c08b9e6624032ae6f9bbf0aa8baed3941b80db0bc0a4d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a183d3e68acecd28ba0a4f9b16b98f36930771c1b6028e0a7571909ddb142736 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a183d3e68acecd28ba0a4f9b16b98f36930771c1b6028e0a7571909ddb142736->enter($__internal_a183d3e68acecd28ba0a4f9b16b98f36930771c1b6028e0a7571909ddb142736_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_840163c8bc6ea49c109c063f0f2f34a47a75d6a41e9dcc5b5e87f4ac63107973 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_840163c8bc6ea49c109c063f0f2f34a47a75d6a41e9dcc5b5e87f4ac63107973->enter($__internal_840163c8bc6ea49c109c063f0f2f34a47a75d6a41e9dcc5b5e87f4ac63107973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a183d3e68acecd28ba0a4f9b16b98f36930771c1b6028e0a7571909ddb142736->leave($__internal_a183d3e68acecd28ba0a4f9b16b98f36930771c1b6028e0a7571909ddb142736_prof);

        
        $__internal_840163c8bc6ea49c109c063f0f2f34a47a75d6a41e9dcc5b5e87f4ac63107973->leave($__internal_840163c8bc6ea49c109c063f0f2f34a47a75d6a41e9dcc5b5e87f4ac63107973_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_018ed347ece7f961b29fda94bb6f90160a4dbe671f3865c682ecd79a95464559 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_018ed347ece7f961b29fda94bb6f90160a4dbe671f3865c682ecd79a95464559->enter($__internal_018ed347ece7f961b29fda94bb6f90160a4dbe671f3865c682ecd79a95464559_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e8308ebd5fba5ce70192e3c61f726c0f44f24ae210ee7566319571a81661d9b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8308ebd5fba5ce70192e3c61f726c0f44f24ae210ee7566319571a81661d9b6->enter($__internal_e8308ebd5fba5ce70192e3c61f726c0f44f24ae210ee7566319571a81661d9b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_e8308ebd5fba5ce70192e3c61f726c0f44f24ae210ee7566319571a81661d9b6->leave($__internal_e8308ebd5fba5ce70192e3c61f726c0f44f24ae210ee7566319571a81661d9b6_prof);

        
        $__internal_018ed347ece7f961b29fda94bb6f90160a4dbe671f3865c682ecd79a95464559->leave($__internal_018ed347ece7f961b29fda94bb6f90160a4dbe671f3865c682ecd79a95464559_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_a66ba27681cbb4d91df1b5cd0a91f4bab35cb3b33d7fa411fa6ac03067229d0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a66ba27681cbb4d91df1b5cd0a91f4bab35cb3b33d7fa411fa6ac03067229d0f->enter($__internal_a66ba27681cbb4d91df1b5cd0a91f4bab35cb3b33d7fa411fa6ac03067229d0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fc64234f4ff913c9d206cfb66562b51e9dc1f6537a9f4fbec51b6a6ab8375fb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc64234f4ff913c9d206cfb66562b51e9dc1f6537a9f4fbec51b6a6ab8375fb3->enter($__internal_fc64234f4ff913c9d206cfb66562b51e9dc1f6537a9f4fbec51b6a6ab8375fb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_fc64234f4ff913c9d206cfb66562b51e9dc1f6537a9f4fbec51b6a6ab8375fb3->leave($__internal_fc64234f4ff913c9d206cfb66562b51e9dc1f6537a9f4fbec51b6a6ab8375fb3_prof);

        
        $__internal_a66ba27681cbb4d91df1b5cd0a91f4bab35cb3b33d7fa411fa6ac03067229d0f->leave($__internal_a66ba27681cbb4d91df1b5cd0a91f4bab35cb3b33d7fa411fa6ac03067229d0f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
