<?php

/* :game:hanged.html.twig */
class __TwigTemplate_db0efb25bc956fb52eb5dd7c1e9cfc20bb3cf566b21d6f10b06fd914777d9441 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":game:hanged.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d5e5e5818e5f6654e9f42c3c525eee0693457d86e30d497bac3255f8543a87ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5e5e5818e5f6654e9f42c3c525eee0693457d86e30d497bac3255f8543a87ff->enter($__internal_d5e5e5818e5f6654e9f42c3c525eee0693457d86e30d497bac3255f8543a87ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:hanged.html.twig"));

        $__internal_5c5f417001ac4dbcc96e486ef86b1c11ccf9ff4aea30d7e414809cfa82647b99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c5f417001ac4dbcc96e486ef86b1c11ccf9ff4aea30d7e414809cfa82647b99->enter($__internal_5c5f417001ac4dbcc96e486ef86b1c11ccf9ff4aea30d7e414809cfa82647b99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:hanged.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d5e5e5818e5f6654e9f42c3c525eee0693457d86e30d497bac3255f8543a87ff->leave($__internal_d5e5e5818e5f6654e9f42c3c525eee0693457d86e30d497bac3255f8543a87ff_prof);

        
        $__internal_5c5f417001ac4dbcc96e486ef86b1c11ccf9ff4aea30d7e414809cfa82647b99->leave($__internal_5c5f417001ac4dbcc96e486ef86b1c11ccf9ff4aea30d7e414809cfa82647b99_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_b2efa7bbefadb06bbde01698f8a875c4ebdce72c1c7f308973e998e0395df791 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2efa7bbefadb06bbde01698f8a875c4ebdce72c1c7f308973e998e0395df791->enter($__internal_b2efa7bbefadb06bbde01698f8a875c4ebdce72c1c7f308973e998e0395df791_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c1a147a2e930f5ee3d3a046b2bb34b956f88d94f2c432e77c630874d56409b1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1a147a2e930f5ee3d3a046b2bb34b956f88d94f2c432e77c630874d56409b1c->enter($__internal_c1a147a2e930f5ee3d3a046b2bb34b956f88d94f2c432e77c630874d56409b1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    <h2>
                        Bad luck! The word was <strong>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "html", null, true);
        echo "</strong>.
                    </h2>           
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game_reset");
        echo "\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
                <div class=\"col-xs-6\">
                    <img src=\"/img/0.png\" alt=\"hangman\" class=\"img-responsive\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_c1a147a2e930f5ee3d3a046b2bb34b956f88d94f2c432e77c630874d56409b1c->leave($__internal_c1a147a2e930f5ee3d3a046b2bb34b956f88d94f2c432e77c630874d56409b1c_prof);

        
        $__internal_b2efa7bbefadb06bbde01698f8a875c4ebdce72c1c7f308973e998e0395df791->leave($__internal_b2efa7bbefadb06bbde01698f8a875c4ebdce72c1c7f308973e998e0395df791_prof);

    }

    public function getTemplateName()
    {
        return ":game:hanged.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 10,  56 => 8,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    <h2>
                        Bad luck! The word was <strong>{{ word }}</strong>.
                    </h2>           
                    <a href=\"{{ path('game_reset')}}\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
                <div class=\"col-xs-6\">
                    <img src=\"/img/0.png\" alt=\"hangman\" class=\"img-responsive\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":game:hanged.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/game/hanged.html.twig");
    }
}
