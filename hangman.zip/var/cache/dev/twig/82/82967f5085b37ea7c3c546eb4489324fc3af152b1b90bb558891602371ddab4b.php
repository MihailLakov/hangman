<?php

/* @Twig/images/icon-plus-square.svg */
class __TwigTemplate_b2445dc77d3a2d3f6535938cb8e36d6631b00c50ec8595bb6d566fee4869a3e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de1a3d80b2186af6eb343d876f2f7bb32c25527f9b0a8fa5ba8bdc329a00a36d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de1a3d80b2186af6eb343d876f2f7bb32c25527f9b0a8fa5ba8bdc329a00a36d->enter($__internal_de1a3d80b2186af6eb343d876f2f7bb32c25527f9b0a8fa5ba8bdc329a00a36d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        $__internal_90bd5a1bb595c8eb08bac744e7c9f2f53941f2a358d333cdd85687cf0adefa0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90bd5a1bb595c8eb08bac744e7c9f2f53941f2a358d333cdd85687cf0adefa0a->enter($__internal_90bd5a1bb595c8eb08bac744e7c9f2f53941f2a358d333cdd85687cf0adefa0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
";
        
        $__internal_de1a3d80b2186af6eb343d876f2f7bb32c25527f9b0a8fa5ba8bdc329a00a36d->leave($__internal_de1a3d80b2186af6eb343d876f2f7bb32c25527f9b0a8fa5ba8bdc329a00a36d_prof);

        
        $__internal_90bd5a1bb595c8eb08bac744e7c9f2f53941f2a358d333cdd85687cf0adefa0a->leave($__internal_90bd5a1bb595c8eb08bac744e7c9f2f53941f2a358d333cdd85687cf0adefa0a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-plus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
", "@Twig/images/icon-plus-square.svg", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\icon-plus-square.svg");
    }
}
