<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_a9371f57abcb570829ae19f8b3669e3e74df5265ab2b7543c5b3d058a9db4118 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d11be2463acf24d838f37323be2d409d20bd10ee72813d919ea08f8bcbf6cd8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d11be2463acf24d838f37323be2d409d20bd10ee72813d919ea08f8bcbf6cd8a->enter($__internal_d11be2463acf24d838f37323be2d409d20bd10ee72813d919ea08f8bcbf6cd8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_efb3feb38c123a62a44acdfa50a34ccfab788a3d274c31dbc85e375fb6672bc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efb3feb38c123a62a44acdfa50a34ccfab788a3d274c31dbc85e375fb6672bc0->enter($__internal_efb3feb38c123a62a44acdfa50a34ccfab788a3d274c31dbc85e375fb6672bc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_d11be2463acf24d838f37323be2d409d20bd10ee72813d919ea08f8bcbf6cd8a->leave($__internal_d11be2463acf24d838f37323be2d409d20bd10ee72813d919ea08f8bcbf6cd8a_prof);

        
        $__internal_efb3feb38c123a62a44acdfa50a34ccfab788a3d274c31dbc85e375fb6672bc0->leave($__internal_efb3feb38c123a62a44acdfa50a34ccfab788a3d274c31dbc85e375fb6672bc0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
