<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_604a9872c0bf5aa6873d038b21f631a1a312f27908d561fe25030d1c1ef60740 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21eac7b842c14458fe507b3b5878e6cc1210cc0d61a732f0649703b4fb44787f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21eac7b842c14458fe507b3b5878e6cc1210cc0d61a732f0649703b4fb44787f->enter($__internal_21eac7b842c14458fe507b3b5878e6cc1210cc0d61a732f0649703b4fb44787f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_23d2aa7eaa1c15545a8fa6ad305079933875a13164c9eff95cca9fd78ec9edd3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23d2aa7eaa1c15545a8fa6ad305079933875a13164c9eff95cca9fd78ec9edd3->enter($__internal_23d2aa7eaa1c15545a8fa6ad305079933875a13164c9eff95cca9fd78ec9edd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_21eac7b842c14458fe507b3b5878e6cc1210cc0d61a732f0649703b4fb44787f->leave($__internal_21eac7b842c14458fe507b3b5878e6cc1210cc0d61a732f0649703b4fb44787f_prof);

        
        $__internal_23d2aa7eaa1c15545a8fa6ad305079933875a13164c9eff95cca9fd78ec9edd3->leave($__internal_23d2aa7eaa1c15545a8fa6ad305079933875a13164c9eff95cca9fd78ec9edd3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
