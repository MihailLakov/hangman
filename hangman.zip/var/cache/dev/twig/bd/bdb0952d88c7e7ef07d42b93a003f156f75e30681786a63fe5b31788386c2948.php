<?php

/* :game:won.html.twig */
class __TwigTemplate_aaf91728b74f7a3f0befc6e462ef4531eaa6046a22d4e4ac60618bbb717db060 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":game:won.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d67e0c28c73bf22a82d9e0a74925ca73c4e709b3f1a9c4ac3f7e33debaab0a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d67e0c28c73bf22a82d9e0a74925ca73c4e709b3f1a9c4ac3f7e33debaab0a6->enter($__internal_6d67e0c28c73bf22a82d9e0a74925ca73c4e709b3f1a9c4ac3f7e33debaab0a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:won.html.twig"));

        $__internal_5e7637fa2676041a5050ee87364a566c8e0e18c7d90a1a6792e35605f7a2eade = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e7637fa2676041a5050ee87364a566c8e0e18c7d90a1a6792e35605f7a2eade->enter($__internal_5e7637fa2676041a5050ee87364a566c8e0e18c7d90a1a6792e35605f7a2eade_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":game:won.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6d67e0c28c73bf22a82d9e0a74925ca73c4e709b3f1a9c4ac3f7e33debaab0a6->leave($__internal_6d67e0c28c73bf22a82d9e0a74925ca73c4e709b3f1a9c4ac3f7e33debaab0a6_prof);

        
        $__internal_5e7637fa2676041a5050ee87364a566c8e0e18c7d90a1a6792e35605f7a2eade->leave($__internal_5e7637fa2676041a5050ee87364a566c8e0e18c7d90a1a6792e35605f7a2eade_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_f9465017ffe0ecb8b7f1cfcdb732b6e3cbc1b859a76654180b49936dd99cd250 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9465017ffe0ecb8b7f1cfcdb732b6e3cbc1b859a76654180b49936dd99cd250->enter($__internal_f9465017ffe0ecb8b7f1cfcdb732b6e3cbc1b859a76654180b49936dd99cd250_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ab6e1b82ea1b24e9f020502d0c3dc91ff5297f5dcdc1e15f125ebde1de10ced0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab6e1b82ea1b24e9f020502d0c3dc91ff5297f5dcdc1e15f125ebde1de10ced0->enter($__internal_ab6e1b82ea1b24e9f020502d0c3dc91ff5297f5dcdc1e15f125ebde1de10ced0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <div class=\"jumbotron\">
                <h2 class=\"success\">
                    Congratulations the word was <strong>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "html", null, true);
        echo "</strong> and you guessed it correctly!
                </h2>              
              
                    <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game_reset");
        echo "\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_ab6e1b82ea1b24e9f020502d0c3dc91ff5297f5dcdc1e15f125ebde1de10ced0->leave($__internal_ab6e1b82ea1b24e9f020502d0c3dc91ff5297f5dcdc1e15f125ebde1de10ced0_prof);

        
        $__internal_f9465017ffe0ecb8b7f1cfcdb732b6e3cbc1b859a76654180b49936dd99cd250->leave($__internal_f9465017ffe0ecb8b7f1cfcdb732b6e3cbc1b859a76654180b49936dd99cd250_prof);

    }

    public function getTemplateName()
    {
        return ":game:won.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 11,  56 => 8,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <div class=\"jumbotron\">
                <h2 class=\"success\">
                    Congratulations the word was <strong>{{ word }}</strong> and you guessed it correctly!
                </h2>              
              
                    <a href=\"{{ path('game_reset')}}\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":game:won.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/game/won.html.twig");
    }
}
