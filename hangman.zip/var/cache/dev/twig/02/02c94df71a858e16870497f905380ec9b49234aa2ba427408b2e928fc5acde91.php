<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_5b2ea2165e89c6ec6d223e5e32f77ba38d1dbd45bfe56bdb226addca88053ecb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9907cfb9999f62ad9c701d1d2ca6128ce52201404faa14bf7458d3c66be7b1c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9907cfb9999f62ad9c701d1d2ca6128ce52201404faa14bf7458d3c66be7b1c8->enter($__internal_9907cfb9999f62ad9c701d1d2ca6128ce52201404faa14bf7458d3c66be7b1c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_e7905c68d7ea91ee1f754b6cb0235138e6904811ba11d38d1aee94167fd89b64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7905c68d7ea91ee1f754b6cb0235138e6904811ba11d38d1aee94167fd89b64->enter($__internal_e7905c68d7ea91ee1f754b6cb0235138e6904811ba11d38d1aee94167fd89b64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_9907cfb9999f62ad9c701d1d2ca6128ce52201404faa14bf7458d3c66be7b1c8->leave($__internal_9907cfb9999f62ad9c701d1d2ca6128ce52201404faa14bf7458d3c66be7b1c8_prof);

        
        $__internal_e7905c68d7ea91ee1f754b6cb0235138e6904811ba11d38d1aee94167fd89b64->leave($__internal_e7905c68d7ea91ee1f754b6cb0235138e6904811ba11d38d1aee94167fd89b64_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
