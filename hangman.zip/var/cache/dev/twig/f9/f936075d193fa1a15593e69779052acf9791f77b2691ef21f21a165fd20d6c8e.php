<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_86125ade15d56c74fc9824edb5fdb91469992029da704c89dac68e723b7d8dd2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e624f30d29035d56face3d501f4d1e835b7aea65d31f88ca8285ebfb986bda47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e624f30d29035d56face3d501f4d1e835b7aea65d31f88ca8285ebfb986bda47->enter($__internal_e624f30d29035d56face3d501f4d1e835b7aea65d31f88ca8285ebfb986bda47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_b6d7b86a2dcf1cb1a8217e7477ab47cfc74d01c9b400ef9bc2ec657fe367773d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6d7b86a2dcf1cb1a8217e7477ab47cfc74d01c9b400ef9bc2ec657fe367773d->enter($__internal_b6d7b86a2dcf1cb1a8217e7477ab47cfc74d01c9b400ef9bc2ec657fe367773d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_e624f30d29035d56face3d501f4d1e835b7aea65d31f88ca8285ebfb986bda47->leave($__internal_e624f30d29035d56face3d501f4d1e835b7aea65d31f88ca8285ebfb986bda47_prof);

        
        $__internal_b6d7b86a2dcf1cb1a8217e7477ab47cfc74d01c9b400ef9bc2ec657fe367773d->leave($__internal_b6d7b86a2dcf1cb1a8217e7477ab47cfc74d01c9b400ef9bc2ec657fe367773d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
