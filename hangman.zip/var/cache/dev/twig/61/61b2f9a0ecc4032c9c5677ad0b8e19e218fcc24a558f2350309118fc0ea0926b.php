<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_662ccc4402379a5f7725f414b5710f752ca7815183e5b9a22be92efd408ac4db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c99c5edb3b38f59befad27b1e59217ee7f4ed25d9b45cc340bf5cb1e354eeaf6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c99c5edb3b38f59befad27b1e59217ee7f4ed25d9b45cc340bf5cb1e354eeaf6->enter($__internal_c99c5edb3b38f59befad27b1e59217ee7f4ed25d9b45cc340bf5cb1e354eeaf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_30f32b7e4585b839f6531d889f34eac9ebcf4a9038f98ae94715c03844ce4298 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30f32b7e4585b839f6531d889f34eac9ebcf4a9038f98ae94715c03844ce4298->enter($__internal_30f32b7e4585b839f6531d889f34eac9ebcf4a9038f98ae94715c03844ce4298_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_c99c5edb3b38f59befad27b1e59217ee7f4ed25d9b45cc340bf5cb1e354eeaf6->leave($__internal_c99c5edb3b38f59befad27b1e59217ee7f4ed25d9b45cc340bf5cb1e354eeaf6_prof);

        
        $__internal_30f32b7e4585b839f6531d889f34eac9ebcf4a9038f98ae94715c03844ce4298->leave($__internal_30f32b7e4585b839f6531d889f34eac9ebcf4a9038f98ae94715c03844ce4298_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
