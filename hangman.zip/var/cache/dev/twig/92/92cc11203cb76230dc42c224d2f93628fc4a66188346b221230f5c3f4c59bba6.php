<?php

/* :word:edit.html.twig */
class __TwigTemplate_15506cd3ceccb9af558151168e74d385246f87d0b7de47f3ed159b8cbc78663c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":word:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10de691ba05f689fc3e4d02d074ed7788c1a1e74315b214fe8e045dbffc9e066 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10de691ba05f689fc3e4d02d074ed7788c1a1e74315b214fe8e045dbffc9e066->enter($__internal_10de691ba05f689fc3e4d02d074ed7788c1a1e74315b214fe8e045dbffc9e066_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:edit.html.twig"));

        $__internal_888b5d289180dfe08980278e39b1085925a22927bbf75b2579ee96c6deee2fe3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_888b5d289180dfe08980278e39b1085925a22927bbf75b2579ee96c6deee2fe3->enter($__internal_888b5d289180dfe08980278e39b1085925a22927bbf75b2579ee96c6deee2fe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_10de691ba05f689fc3e4d02d074ed7788c1a1e74315b214fe8e045dbffc9e066->leave($__internal_10de691ba05f689fc3e4d02d074ed7788c1a1e74315b214fe8e045dbffc9e066_prof);

        
        $__internal_888b5d289180dfe08980278e39b1085925a22927bbf75b2579ee96c6deee2fe3->leave($__internal_888b5d289180dfe08980278e39b1085925a22927bbf75b2579ee96c6deee2fe3_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_092e54d4c55a2670b019f7e1678938a5ae2276eb8d5a4c3a2182ff78e5b36b4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_092e54d4c55a2670b019f7e1678938a5ae2276eb8d5a4c3a2182ff78e5b36b4f->enter($__internal_092e54d4c55a2670b019f7e1678938a5ae2276eb8d5a4c3a2182ff78e5b36b4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_88de033f6994f9771ecb0dc6796070c8d37dcbb85517091e9b8fe73ca716fbee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88de033f6994f9771ecb0dc6796070c8d37dcbb85517091e9b8fe73ca716fbee->enter($__internal_88de033f6994f9771ecb0dc6796070c8d37dcbb85517091e9b8fe73ca716fbee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word edit</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Edit\" class=\"btn btn-primary\"/>
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            ";
        // line 22
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_88de033f6994f9771ecb0dc6796070c8d37dcbb85517091e9b8fe73ca716fbee->leave($__internal_88de033f6994f9771ecb0dc6796070c8d37dcbb85517091e9b8fe73ca716fbee_prof);

        
        $__internal_092e54d4c55a2670b019f7e1678938a5ae2276eb8d5a4c3a2182ff78e5b36b4f->leave($__internal_092e54d4c55a2670b019f7e1678938a5ae2276eb8d5a4c3a2182ff78e5b36b4f_prof);

    }

    public function getTemplateName()
    {
        return ":word:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 22,  79 => 20,  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word edit</h1>

                    {{ form_start(edit_form) }}
                    {{ form_widget(edit_form) }}
                    <input type=\"submit\" value=\"Edit\" class=\"btn btn-primary\"/>
                    {{ form_end(edit_form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('word_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            {{ form_start(delete_form) }}
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            {{ form_end(delete_form) }}
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":word:edit.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/word/edit.html.twig");
    }
}
