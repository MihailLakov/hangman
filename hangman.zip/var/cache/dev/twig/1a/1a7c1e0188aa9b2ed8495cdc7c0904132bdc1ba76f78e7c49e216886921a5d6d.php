<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_14078ac77447ef8c1183dc2470c26f802f8e3353eb77b32f590d6c4e623168df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee6cd97eeeb60389c4bb9694c5311b7c50950df15bd6c6ac160eeef1212c72c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee6cd97eeeb60389c4bb9694c5311b7c50950df15bd6c6ac160eeef1212c72c7->enter($__internal_ee6cd97eeeb60389c4bb9694c5311b7c50950df15bd6c6ac160eeef1212c72c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_9585419215f638c5177eafb6f239e77aa4cb28e8461a54c526175f1c3d5b6eda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9585419215f638c5177eafb6f239e77aa4cb28e8461a54c526175f1c3d5b6eda->enter($__internal_9585419215f638c5177eafb6f239e77aa4cb28e8461a54c526175f1c3d5b6eda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_ee6cd97eeeb60389c4bb9694c5311b7c50950df15bd6c6ac160eeef1212c72c7->leave($__internal_ee6cd97eeeb60389c4bb9694c5311b7c50950df15bd6c6ac160eeef1212c72c7_prof);

        
        $__internal_9585419215f638c5177eafb6f239e77aa4cb28e8461a54c526175f1c3d5b6eda->leave($__internal_9585419215f638c5177eafb6f239e77aa4cb28e8461a54c526175f1c3d5b6eda_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
