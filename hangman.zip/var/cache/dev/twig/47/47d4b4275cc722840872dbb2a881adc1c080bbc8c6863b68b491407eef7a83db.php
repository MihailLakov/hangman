<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_b7478cacc288bd5ee1de1d083556ca8a8a5bd472f913783e54b0eec7137ee13d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee6add2663d0d86dfbe3863aa0a4fd89acc682e3d8fcac7e6c3573a2e5ab49b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee6add2663d0d86dfbe3863aa0a4fd89acc682e3d8fcac7e6c3573a2e5ab49b9->enter($__internal_ee6add2663d0d86dfbe3863aa0a4fd89acc682e3d8fcac7e6c3573a2e5ab49b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_0521f5fe6f786c03b8b1ec1aad16cdc3c18fd224689b686e83144fff8f2f422b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0521f5fe6f786c03b8b1ec1aad16cdc3c18fd224689b686e83144fff8f2f422b->enter($__internal_0521f5fe6f786c03b8b1ec1aad16cdc3c18fd224689b686e83144fff8f2f422b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_ee6add2663d0d86dfbe3863aa0a4fd89acc682e3d8fcac7e6c3573a2e5ab49b9->leave($__internal_ee6add2663d0d86dfbe3863aa0a4fd89acc682e3d8fcac7e6c3573a2e5ab49b9_prof);

        
        $__internal_0521f5fe6f786c03b8b1ec1aad16cdc3c18fd224689b686e83144fff8f2f422b->leave($__internal_0521f5fe6f786c03b8b1ec1aad16cdc3c18fd224689b686e83144fff8f2f422b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
