<?php

/* ::footer.html.twig */
class __TwigTemplate_1fd7dace87c45bc21247b220985c6c79dd8044b1e5670ebeaf0427a08e5317cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a57957f638d8f5fd32981639a85f7f3c98f5e82fd5b2a1098306166ea3e7492c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a57957f638d8f5fd32981639a85f7f3c98f5e82fd5b2a1098306166ea3e7492c->enter($__internal_a57957f638d8f5fd32981639a85f7f3c98f5e82fd5b2a1098306166ea3e7492c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::footer.html.twig"));

        $__internal_751e27abc223c64c0d2cdee661f335be62f3fd5db9c8cf01fc86db9c6fb7cdbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_751e27abc223c64c0d2cdee661f335be62f3fd5db9c8cf01fc86db9c6fb7cdbb->enter($__internal_751e27abc223c64c0d2cdee661f335be62f3fd5db9c8cf01fc86db9c6fb7cdbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::footer.html.twig"));

        // line 1
        echo "<footer>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <p> ";
        // line 5
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " &copy; Mihail</p>
            </div>
        </div>
    </div>    
</footer>
       
                
   ";
        
        $__internal_a57957f638d8f5fd32981639a85f7f3c98f5e82fd5b2a1098306166ea3e7492c->leave($__internal_a57957f638d8f5fd32981639a85f7f3c98f5e82fd5b2a1098306166ea3e7492c_prof);

        
        $__internal_751e27abc223c64c0d2cdee661f335be62f3fd5db9c8cf01fc86db9c6fb7cdbb->leave($__internal_751e27abc223c64c0d2cdee661f335be62f3fd5db9c8cf01fc86db9c6fb7cdbb_prof);

    }

    public function getTemplateName()
    {
        return "::footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<footer>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <p> {{ 'now'|date('Y') }} &copy; Mihail</p>
            </div>
        </div>
    </div>    
</footer>
       
                
   ", "::footer.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/footer.html.twig");
    }
}
