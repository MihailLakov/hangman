<?php

/* :word:new.html.twig */
class __TwigTemplate_6a3987f959564ed3887da82ade3cb0a2d99098c18c744c5b36541396ddec7282 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":word:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2929fcddb660ba9dd2381f71f7f51a96812088b52cf12ef443086fa2ae2029ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2929fcddb660ba9dd2381f71f7f51a96812088b52cf12ef443086fa2ae2029ce->enter($__internal_2929fcddb660ba9dd2381f71f7f51a96812088b52cf12ef443086fa2ae2029ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:new.html.twig"));

        $__internal_08a72e8f465d90cd7d4d2c5b59aa741ec8492c5720a54b1399552fbc5625c8f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08a72e8f465d90cd7d4d2c5b59aa741ec8492c5720a54b1399552fbc5625c8f6->enter($__internal_08a72e8f465d90cd7d4d2c5b59aa741ec8492c5720a54b1399552fbc5625c8f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2929fcddb660ba9dd2381f71f7f51a96812088b52cf12ef443086fa2ae2029ce->leave($__internal_2929fcddb660ba9dd2381f71f7f51a96812088b52cf12ef443086fa2ae2029ce_prof);

        
        $__internal_08a72e8f465d90cd7d4d2c5b59aa741ec8492c5720a54b1399552fbc5625c8f6->leave($__internal_08a72e8f465d90cd7d4d2c5b59aa741ec8492c5720a54b1399552fbc5625c8f6_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ba2df8dc91a46dc6f084133a8a1958efe5091949b8bdf9fc24cf08641d71b80f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba2df8dc91a46dc6f084133a8a1958efe5091949b8bdf9fc24cf08641d71b80f->enter($__internal_ba2df8dc91a46dc6f084133a8a1958efe5091949b8bdf9fc24cf08641d71b80f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0287985772f2393d428fa2181d7114ec65879574150c363d005d174a5d4d064c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0287985772f2393d428fa2181d7114ec65879574150c363d005d174a5d4d064c->enter($__internal_0287985772f2393d428fa2181d7114ec65879574150c363d005d174a5d4d064c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word creation</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\" />
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_0287985772f2393d428fa2181d7114ec65879574150c363d005d174a5d4d064c->leave($__internal_0287985772f2393d428fa2181d7114ec65879574150c363d005d174a5d4d064c_prof);

        
        $__internal_ba2df8dc91a46dc6f084133a8a1958efe5091949b8bdf9fc24cf08641d71b80f->leave($__internal_ba2df8dc91a46dc6f084133a8a1958efe5091949b8bdf9fc24cf08641d71b80f_prof);

    }

    public function getTemplateName()
    {
        return ":word:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word creation</h1>

                    {{ form_start(form) }}
                    {{ form_widget(form) }}
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\" />
                    {{ form_end(form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('word_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":word:new.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/word/new.html.twig");
    }
}
