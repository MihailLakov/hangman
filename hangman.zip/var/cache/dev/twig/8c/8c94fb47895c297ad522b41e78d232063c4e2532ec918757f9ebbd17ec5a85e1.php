<?php

/* category/edit.html.twig */
class __TwigTemplate_c744a9155bd0b71b033f5901de09a8ca4951bff7c286e98ff6c6bf26d39f8ecd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_590763942ec031108e6e2442bfd58f638ed47b859be89e2d9417ea0414c24f1c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_590763942ec031108e6e2442bfd58f638ed47b859be89e2d9417ea0414c24f1c->enter($__internal_590763942ec031108e6e2442bfd58f638ed47b859be89e2d9417ea0414c24f1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/edit.html.twig"));

        $__internal_77d25b190af2448a739363a18d0bdb4066e13e052c92a8901017e818fe5a4a4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77d25b190af2448a739363a18d0bdb4066e13e052c92a8901017e818fe5a4a4f->enter($__internal_77d25b190af2448a739363a18d0bdb4066e13e052c92a8901017e818fe5a4a4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_590763942ec031108e6e2442bfd58f638ed47b859be89e2d9417ea0414c24f1c->leave($__internal_590763942ec031108e6e2442bfd58f638ed47b859be89e2d9417ea0414c24f1c_prof);

        
        $__internal_77d25b190af2448a739363a18d0bdb4066e13e052c92a8901017e818fe5a4a4f->leave($__internal_77d25b190af2448a739363a18d0bdb4066e13e052c92a8901017e818fe5a4a4f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a238043b54040ad877503af9e1f34071331aa7937d6a2aaaac349e1e5b23186e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a238043b54040ad877503af9e1f34071331aa7937d6a2aaaac349e1e5b23186e->enter($__internal_a238043b54040ad877503af9e1f34071331aa7937d6a2aaaac349e1e5b23186e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9ef56602498a7fc210a01aee67eb97b21b7cab7e0689b22b197ae03eb534ee2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ef56602498a7fc210a01aee67eb97b21b7cab7e0689b22b197ae03eb534ee2c->enter($__internal_9ef56602498a7fc210a01aee67eb97b21b7cab7e0689b22b197ae03eb534ee2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Category Edit</h1>
                ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
                ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
                <input type=\"submit\" value=\"Submit edit\" class=\"btn btn-info\" />
                ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "
                <ul>
                    <li>
                        <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                    </li>
                    <li>
                        ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                        <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                        ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                    </li>
                </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_9ef56602498a7fc210a01aee67eb97b21b7cab7e0689b22b197ae03eb534ee2c->leave($__internal_9ef56602498a7fc210a01aee67eb97b21b7cab7e0689b22b197ae03eb534ee2c_prof);

        
        $__internal_a238043b54040ad877503af9e1f34071331aa7937d6a2aaaac349e1e5b23186e->leave($__internal_a238043b54040ad877503af9e1f34071331aa7937d6a2aaaac349e1e5b23186e_prof);

    }

    public function getTemplateName()
    {
        return "category/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 20,  77 => 18,  71 => 15,  65 => 12,  60 => 10,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Category Edit</h1>
                {{ form_start(edit_form) }}
                {{ form_widget(edit_form) }}
                <input type=\"submit\" value=\"Submit edit\" class=\"btn btn-info\" />
                {{ form_end(edit_form) }}
                <ul>
                    <li>
                        <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                    </li>
                    <li>
                        {{ form_start(delete_form) }}
                        <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                        {{ form_end(delete_form) }}
                    </li>
                </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "category/edit.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\category\\edit.html.twig");
    }
}
