<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_7020c4d2459021e8056db397883c656b936d37943dfe53c2f3bc8d1395c6c51e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f5a613b8a3af8631960774d5f5e4852bfd101020c804ac4c101343d2add53d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f5a613b8a3af8631960774d5f5e4852bfd101020c804ac4c101343d2add53d8->enter($__internal_2f5a613b8a3af8631960774d5f5e4852bfd101020c804ac4c101343d2add53d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_bc2ef84e37af14ca2d7f4584b9710101c1ab89669e837ea2d2c839f03f15cd63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc2ef84e37af14ca2d7f4584b9710101c1ab89669e837ea2d2c839f03f15cd63->enter($__internal_bc2ef84e37af14ca2d7f4584b9710101c1ab89669e837ea2d2c839f03f15cd63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_2f5a613b8a3af8631960774d5f5e4852bfd101020c804ac4c101343d2add53d8->leave($__internal_2f5a613b8a3af8631960774d5f5e4852bfd101020c804ac4c101343d2add53d8_prof);

        
        $__internal_bc2ef84e37af14ca2d7f4584b9710101c1ab89669e837ea2d2c839f03f15cd63->leave($__internal_bc2ef84e37af14ca2d7f4584b9710101c1ab89669e837ea2d2c839f03f15cd63_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
