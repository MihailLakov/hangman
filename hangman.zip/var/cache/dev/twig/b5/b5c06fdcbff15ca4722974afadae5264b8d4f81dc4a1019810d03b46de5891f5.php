<?php

/* :default:register.html.twig */
class __TwigTemplate_a0aeec22fccb054fae96ecea0afacc026e644de7c444b2f87fbad104078b0190 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:register.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_441aadfcebef5ab4ae0e8390d86cb569f24679c7e55baac99fd10770835bde6e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_441aadfcebef5ab4ae0e8390d86cb569f24679c7e55baac99fd10770835bde6e->enter($__internal_441aadfcebef5ab4ae0e8390d86cb569f24679c7e55baac99fd10770835bde6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:register.html.twig"));

        $__internal_b17b25cda19ba56906b5ff165a9e79be2baa95e8af8695026150f5ce8b64b958 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b17b25cda19ba56906b5ff165a9e79be2baa95e8af8695026150f5ce8b64b958->enter($__internal_b17b25cda19ba56906b5ff165a9e79be2baa95e8af8695026150f5ce8b64b958_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_441aadfcebef5ab4ae0e8390d86cb569f24679c7e55baac99fd10770835bde6e->leave($__internal_441aadfcebef5ab4ae0e8390d86cb569f24679c7e55baac99fd10770835bde6e_prof);

        
        $__internal_b17b25cda19ba56906b5ff165a9e79be2baa95e8af8695026150f5ce8b64b958->leave($__internal_b17b25cda19ba56906b5ff165a9e79be2baa95e8af8695026150f5ce8b64b958_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f56e264218e95e2da58fc7182fcf0111dd197f6d7fffc0a35a1b3ee1e3bff7fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f56e264218e95e2da58fc7182fcf0111dd197f6d7fffc0a35a1b3ee1e3bff7fb->enter($__internal_f56e264218e95e2da58fc7182fcf0111dd197f6d7fffc0a35a1b3ee1e3bff7fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8c5a7a8c1198b213e5c187dc271ef0e2a2d99518674491fccf617b63abfeb6a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c5a7a8c1198b213e5c187dc271ef0e2a2d99518674491fccf617b63abfeb6a2->enter($__internal_8c5a7a8c1198b213e5c187dc271ef0e2a2d99518674491fccf617b63abfeb6a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"jumbotron\">
                <h2>Register a new account</h2>
                ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'form_start');
        echo "
                ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'widget');
        echo "
                <input type=\"submit\" value=\"Submit\" class=\"btn btn-primary btn-lg\">
                ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'rest');
        echo "
                ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'form_end');
        echo "
            </div>
        </div>
    </div>
";
        
        $__internal_8c5a7a8c1198b213e5c187dc271ef0e2a2d99518674491fccf617b63abfeb6a2->leave($__internal_8c5a7a8c1198b213e5c187dc271ef0e2a2d99518674491fccf617b63abfeb6a2_prof);

        
        $__internal_f56e264218e95e2da58fc7182fcf0111dd197f6d7fffc0a35a1b3ee1e3bff7fb->leave($__internal_f56e264218e95e2da58fc7182fcf0111dd197f6d7fffc0a35a1b3ee1e3bff7fb_prof);

    }

    public function getTemplateName()
    {
        return ":default:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 12,  64 => 11,  59 => 9,  55 => 8,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"jumbotron\">
                <h2>Register a new account</h2>
                {{ form_start(registerForm) }}
                {{ form_widget(registerForm) }}
                <input type=\"submit\" value=\"Submit\" class=\"btn btn-primary btn-lg\">
                {{ form_rest(registerForm) }}
                {{ form_end(registerForm) }}
            </div>
        </div>
    </div>
{% endblock %}
", ":default:register.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/default/register.html.twig");
    }
}
