<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b95f7ab30d76a04980f24bd0199c881ce189c1a769f07275d0dfd7c1b15da1bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_775139abd498ae92dfa3244dcf35fe33903b3f216daa4dadcbe21ae3014ae913 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_775139abd498ae92dfa3244dcf35fe33903b3f216daa4dadcbe21ae3014ae913->enter($__internal_775139abd498ae92dfa3244dcf35fe33903b3f216daa4dadcbe21ae3014ae913_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_0cf055aced8ca211e462e0eac89dbdb4b6cb1c11a35f207e608834395a9161a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cf055aced8ca211e462e0eac89dbdb4b6cb1c11a35f207e608834395a9161a3->enter($__internal_0cf055aced8ca211e462e0eac89dbdb4b6cb1c11a35f207e608834395a9161a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_775139abd498ae92dfa3244dcf35fe33903b3f216daa4dadcbe21ae3014ae913->leave($__internal_775139abd498ae92dfa3244dcf35fe33903b3f216daa4dadcbe21ae3014ae913_prof);

        
        $__internal_0cf055aced8ca211e462e0eac89dbdb4b6cb1c11a35f207e608834395a9161a3->leave($__internal_0cf055aced8ca211e462e0eac89dbdb4b6cb1c11a35f207e608834395a9161a3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_56966054de653d95b54d3c1fbd136fb3e27a27657dc2df455f798e419b6b48c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56966054de653d95b54d3c1fbd136fb3e27a27657dc2df455f798e419b6b48c3->enter($__internal_56966054de653d95b54d3c1fbd136fb3e27a27657dc2df455f798e419b6b48c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_388c7a791593669af35330cc1bea62092201059788329b92babd9d8e3bc5c815 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_388c7a791593669af35330cc1bea62092201059788329b92babd9d8e3bc5c815->enter($__internal_388c7a791593669af35330cc1bea62092201059788329b92babd9d8e3bc5c815_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_388c7a791593669af35330cc1bea62092201059788329b92babd9d8e3bc5c815->leave($__internal_388c7a791593669af35330cc1bea62092201059788329b92babd9d8e3bc5c815_prof);

        
        $__internal_56966054de653d95b54d3c1fbd136fb3e27a27657dc2df455f798e419b6b48c3->leave($__internal_56966054de653d95b54d3c1fbd136fb3e27a27657dc2df455f798e419b6b48c3_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_8a46fdaf1046b15821a5d78389be408b91198fa91a2b1f973da30df57e73ab13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a46fdaf1046b15821a5d78389be408b91198fa91a2b1f973da30df57e73ab13->enter($__internal_8a46fdaf1046b15821a5d78389be408b91198fa91a2b1f973da30df57e73ab13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ec6101642e85f6b2df16a2fe908346686621efcf75267844b0e151dde61e2fbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec6101642e85f6b2df16a2fe908346686621efcf75267844b0e151dde61e2fbd->enter($__internal_ec6101642e85f6b2df16a2fe908346686621efcf75267844b0e151dde61e2fbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ec6101642e85f6b2df16a2fe908346686621efcf75267844b0e151dde61e2fbd->leave($__internal_ec6101642e85f6b2df16a2fe908346686621efcf75267844b0e151dde61e2fbd_prof);

        
        $__internal_8a46fdaf1046b15821a5d78389be408b91198fa91a2b1f973da30df57e73ab13->leave($__internal_8a46fdaf1046b15821a5d78389be408b91198fa91a2b1f973da30df57e73ab13_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_474d91529977b32ca6bf052745616dfb16cdbd52750ef41bec4258b3d5c03ed0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_474d91529977b32ca6bf052745616dfb16cdbd52750ef41bec4258b3d5c03ed0->enter($__internal_474d91529977b32ca6bf052745616dfb16cdbd52750ef41bec4258b3d5c03ed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_3fd49e4759282f6c1f2cb2cec4dcfe04ecf64dcb5f105e331415674d606bcf3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fd49e4759282f6c1f2cb2cec4dcfe04ecf64dcb5f105e331415674d606bcf3c->enter($__internal_3fd49e4759282f6c1f2cb2cec4dcfe04ecf64dcb5f105e331415674d606bcf3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_3fd49e4759282f6c1f2cb2cec4dcfe04ecf64dcb5f105e331415674d606bcf3c->leave($__internal_3fd49e4759282f6c1f2cb2cec4dcfe04ecf64dcb5f105e331415674d606bcf3c_prof);

        
        $__internal_474d91529977b32ca6bf052745616dfb16cdbd52750ef41bec4258b3d5c03ed0->leave($__internal_474d91529977b32ca6bf052745616dfb16cdbd52750ef41bec4258b3d5c03ed0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
