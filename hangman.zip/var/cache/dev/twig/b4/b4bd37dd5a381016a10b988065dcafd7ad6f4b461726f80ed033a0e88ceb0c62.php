<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_85e1e648f6b606b8662682dcff40eefaca6e8ac83299b7ca82b4a05783b92831 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b3c4dc9922820baf26d91cd613e597a8c76352a4a98ac17b891de6f89a13be4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b3c4dc9922820baf26d91cd613e597a8c76352a4a98ac17b891de6f89a13be4->enter($__internal_2b3c4dc9922820baf26d91cd613e597a8c76352a4a98ac17b891de6f89a13be4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_c7ecff9909c225071c951255cbc2f2e8a367108f2e453d178f3da0c923a679ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7ecff9909c225071c951255cbc2f2e8a367108f2e453d178f3da0c923a679ab->enter($__internal_c7ecff9909c225071c951255cbc2f2e8a367108f2e453d178f3da0c923a679ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_2b3c4dc9922820baf26d91cd613e597a8c76352a4a98ac17b891de6f89a13be4->leave($__internal_2b3c4dc9922820baf26d91cd613e597a8c76352a4a98ac17b891de6f89a13be4_prof);

        
        $__internal_c7ecff9909c225071c951255cbc2f2e8a367108f2e453d178f3da0c923a679ab->leave($__internal_c7ecff9909c225071c951255cbc2f2e8a367108f2e453d178f3da0c923a679ab_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
