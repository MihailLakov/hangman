<?php

/* default/login.html.twig */
class __TwigTemplate_7f4ceef5d09d4c27b60e309029e86a44d186c6109980f33542024800daf4582d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea1a1ea2badd9ff446a07871f88c1c5644a3ba428160f19a96f52ed73952929a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea1a1ea2badd9ff446a07871f88c1c5644a3ba428160f19a96f52ed73952929a->enter($__internal_ea1a1ea2badd9ff446a07871f88c1c5644a3ba428160f19a96f52ed73952929a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $__internal_6bc5dca05ce6d3aa54f6c55534115636ae052e520f420ffff02a1fa1f1576a75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6bc5dca05ce6d3aa54f6c55534115636ae052e520f420ffff02a1fa1f1576a75->enter($__internal_6bc5dca05ce6d3aa54f6c55534115636ae052e520f420ffff02a1fa1f1576a75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ea1a1ea2badd9ff446a07871f88c1c5644a3ba428160f19a96f52ed73952929a->leave($__internal_ea1a1ea2badd9ff446a07871f88c1c5644a3ba428160f19a96f52ed73952929a_prof);

        
        $__internal_6bc5dca05ce6d3aa54f6c55534115636ae052e520f420ffff02a1fa1f1576a75->leave($__internal_6bc5dca05ce6d3aa54f6c55534115636ae052e520f420ffff02a1fa1f1576a75_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_dd106d565903c80d50f08790fb87e8a08d58b60ebaa6d44264a6e25c295c462c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd106d565903c80d50f08790fb87e8a08d58b60ebaa6d44264a6e25c295c462c->enter($__internal_dd106d565903c80d50f08790fb87e8a08d58b60ebaa6d44264a6e25c295c462c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9eb305df68d3b65e3a5278bd9a95418462e44dfa80cdf1d9c3c93f98b7ab1057 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9eb305df68d3b65e3a5278bd9a95418462e44dfa80cdf1d9c3c93f98b7ab1057->enter($__internal_9eb305df68d3b65e3a5278bd9a95418462e44dfa80cdf1d9c3c93f98b7ab1057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2> Please login to play Hangman! </h2>
                    <p>You can't play our awesome game without having an account</p>
                    ";
        // line 10
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 11
            echo "                        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
                    ";
        }
        // line 13
        echo "                </div>
                <div class=\"col-xs-12\">
                    <form action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-login");
        echo "\" method=\"POST\">
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Username</label>
                            <input type=\"text\" name=\"_username\" class=\"form-control\"> 
                        </div>
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Password</label>
                            <input type=\"password\" name=\"_password\" class=\"form-control\"> 
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn btn-bg btn-primary\">Login </button>
                        <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-register");
        echo "\" class=\"btn btn-info btn-bg\"> Register new account</a>
                    </form>
                </div>      
            </div>      
        </div>
    </div>
";
        
        $__internal_9eb305df68d3b65e3a5278bd9a95418462e44dfa80cdf1d9c3c93f98b7ab1057->leave($__internal_9eb305df68d3b65e3a5278bd9a95418462e44dfa80cdf1d9c3c93f98b7ab1057_prof);

        
        $__internal_dd106d565903c80d50f08790fb87e8a08d58b60ebaa6d44264a6e25c295c462c->leave($__internal_dd106d565903c80d50f08790fb87e8a08d58b60ebaa6d44264a6e25c295c462c_prof);

    }

    public function getTemplateName()
    {
        return "default/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 26,  81 => 24,  69 => 15,  65 => 13,  59 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2> Please login to play Hangman! </h2>
                    <p>You can't play our awesome game without having an account</p>
                    {% if error %}
                        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
                    {% endif %}
                </div>
                <div class=\"col-xs-12\">
                    <form action=\"{{path('security-login')}}\" method=\"POST\">
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Username</label>
                            <input type=\"text\" name=\"_username\" class=\"form-control\"> 
                        </div>
                        <div class=\"form-group\">
                            <label class=\"control-label\" for=\"_username\">Password</label>
                            <input type=\"password\" name=\"_password\" class=\"form-control\"> 
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/>
                        <button type=\"submit\" class=\"btn btn-bg btn-primary\">Login </button>
                        <a href=\"{{path('security-register')}}\" class=\"btn btn-info btn-bg\"> Register new account</a>
                    </form>
                </div>      
            </div>      
        </div>
    </div>
{% endblock %}
", "default/login.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\default\\login.html.twig");
    }
}
