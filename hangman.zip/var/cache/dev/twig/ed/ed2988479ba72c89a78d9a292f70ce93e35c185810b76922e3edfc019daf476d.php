<?php

/* category/show.html.twig */
class __TwigTemplate_b7bd7fef683d77ad8de19db9f71b7076c84b67167f098a87845e2281e4c44b52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e72d9b61f3a18843a804928f42e769a65503ed7f309b4fb0c8e9db6aefa571ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e72d9b61f3a18843a804928f42e769a65503ed7f309b4fb0c8e9db6aefa571ba->enter($__internal_e72d9b61f3a18843a804928f42e769a65503ed7f309b4fb0c8e9db6aefa571ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/show.html.twig"));

        $__internal_45bf06c075aec372234398bf702139148ad1f3d4ed33e3fa31faa677a24fd1b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45bf06c075aec372234398bf702139148ad1f3d4ed33e3fa31faa677a24fd1b1->enter($__internal_45bf06c075aec372234398bf702139148ad1f3d4ed33e3fa31faa677a24fd1b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e72d9b61f3a18843a804928f42e769a65503ed7f309b4fb0c8e9db6aefa571ba->leave($__internal_e72d9b61f3a18843a804928f42e769a65503ed7f309b4fb0c8e9db6aefa571ba_prof);

        
        $__internal_45bf06c075aec372234398bf702139148ad1f3d4ed33e3fa31faa677a24fd1b1->leave($__internal_45bf06c075aec372234398bf702139148ad1f3d4ed33e3fa31faa677a24fd1b1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_aa6c692b45a3760c9d6d3e989621b3b526c0abdbf27f417374ef14c0d1d32bd8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa6c692b45a3760c9d6d3e989621b3b526c0abdbf27f417374ef14c0d1d32bd8->enter($__internal_aa6c692b45a3760c9d6d3e989621b3b526c0abdbf27f417374ef14c0d1d32bd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d36c13d5c47814afbf8bb8479cb052dbd8781ebf4e9742e1a33b69ab5d8515fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d36c13d5c47814afbf8bb8479cb052dbd8781ebf4e9742e1a33b69ab5d8515fc->enter($__internal_d36c13d5c47814afbf8bb8479cb052dbd8781ebf4e9742e1a33b69ab5d8515fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category</h1>
                    <table>
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()), "html", null, true);
        echo "</td>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "title", array()), "html", null, true);
        echo "</td>
                            </tr>
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            ";
        // line 29
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            ";
        // line 31
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_d36c13d5c47814afbf8bb8479cb052dbd8781ebf4e9742e1a33b69ab5d8515fc->leave($__internal_d36c13d5c47814afbf8bb8479cb052dbd8781ebf4e9742e1a33b69ab5d8515fc_prof);

        
        $__internal_aa6c692b45a3760c9d6d3e989621b3b526c0abdbf27f417374ef14c0d1d32bd8->leave($__internal_aa6c692b45a3760c9d6d3e989621b3b526c0abdbf27f417374ef14c0d1d32bd8_prof);

    }

    public function getTemplateName()
    {
        return "category/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 31,  88 => 29,  82 => 26,  76 => 23,  67 => 17,  60 => 13,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category</h1>
                    <table>
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>{{ category.id }}</td>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td>{{ category.title }}</td>
                            </tr>
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"{{ path('category_edit', { 'id': category.id }) }}\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            {{ form_start(delete_form) }}
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            {{ form_end(delete_form) }}
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "category/show.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\category\\show.html.twig");
    }
}
