<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_08d80608ec3de0cb205cfaf08d5bda717c43cdff2fcc21c4c3fbd4b04909f10b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8067cbb98103702112b346e370e743449cc2f78b3a5437c83e02def3ebd7f2ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8067cbb98103702112b346e370e743449cc2f78b3a5437c83e02def3ebd7f2ea->enter($__internal_8067cbb98103702112b346e370e743449cc2f78b3a5437c83e02def3ebd7f2ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_66b2fbf24330a4d7fdc295ae3b0a34d2ce0a5ce18b64ab7f5c55b87605176a46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66b2fbf24330a4d7fdc295ae3b0a34d2ce0a5ce18b64ab7f5c55b87605176a46->enter($__internal_66b2fbf24330a4d7fdc295ae3b0a34d2ce0a5ce18b64ab7f5c55b87605176a46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_8067cbb98103702112b346e370e743449cc2f78b3a5437c83e02def3ebd7f2ea->leave($__internal_8067cbb98103702112b346e370e743449cc2f78b3a5437c83e02def3ebd7f2ea_prof);

        
        $__internal_66b2fbf24330a4d7fdc295ae3b0a34d2ce0a5ce18b64ab7f5c55b87605176a46->leave($__internal_66b2fbf24330a4d7fdc295ae3b0a34d2ce0a5ce18b64ab7f5c55b87605176a46_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_attributes.html.php");
    }
}
