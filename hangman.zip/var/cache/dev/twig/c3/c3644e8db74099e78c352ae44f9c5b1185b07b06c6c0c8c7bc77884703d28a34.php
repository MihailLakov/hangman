<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_b59dc6c72091c9c852636259a4a7e537fd79d7b5f22ac2166e2ba6acd0f2df3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d58521fcdef2abc227bcfb7a7517a76e3c2b1348c5ee53023dddd144b362d5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d58521fcdef2abc227bcfb7a7517a76e3c2b1348c5ee53023dddd144b362d5c->enter($__internal_5d58521fcdef2abc227bcfb7a7517a76e3c2b1348c5ee53023dddd144b362d5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_e4032198906a03a458bbadbed6d9aee5edb8c785d67c68b6e98fce593807a785 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4032198906a03a458bbadbed6d9aee5edb8c785d67c68b6e98fce593807a785->enter($__internal_e4032198906a03a458bbadbed6d9aee5edb8c785d67c68b6e98fce593807a785_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5d58521fcdef2abc227bcfb7a7517a76e3c2b1348c5ee53023dddd144b362d5c->leave($__internal_5d58521fcdef2abc227bcfb7a7517a76e3c2b1348c5ee53023dddd144b362d5c_prof);

        
        $__internal_e4032198906a03a458bbadbed6d9aee5edb8c785d67c68b6e98fce593807a785->leave($__internal_e4032198906a03a458bbadbed6d9aee5edb8c785d67c68b6e98fce593807a785_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_62d06f20bcd9ba80fe60abb6577edc3481510e9398bbece3f878a63109ab30d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62d06f20bcd9ba80fe60abb6577edc3481510e9398bbece3f878a63109ab30d0->enter($__internal_62d06f20bcd9ba80fe60abb6577edc3481510e9398bbece3f878a63109ab30d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_bf26ea08febbc605310c4321c19aa0db15f2216deedfb400e115a20406d69c45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf26ea08febbc605310c4321c19aa0db15f2216deedfb400e115a20406d69c45->enter($__internal_bf26ea08febbc605310c4321c19aa0db15f2216deedfb400e115a20406d69c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_bf26ea08febbc605310c4321c19aa0db15f2216deedfb400e115a20406d69c45->leave($__internal_bf26ea08febbc605310c4321c19aa0db15f2216deedfb400e115a20406d69c45_prof);

        
        $__internal_62d06f20bcd9ba80fe60abb6577edc3481510e9398bbece3f878a63109ab30d0->leave($__internal_62d06f20bcd9ba80fe60abb6577edc3481510e9398bbece3f878a63109ab30d0_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_e8fbc9e2f50c5225c0de9571a21eaa01ebe4af8fdf0c6c7d91fff5b62c671380 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8fbc9e2f50c5225c0de9571a21eaa01ebe4af8fdf0c6c7d91fff5b62c671380->enter($__internal_e8fbc9e2f50c5225c0de9571a21eaa01ebe4af8fdf0c6c7d91fff5b62c671380_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_478a4ca51a49a13bdb140abdccec3158ef8b07b9778f61e9f59030ad2e9e5550 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_478a4ca51a49a13bdb140abdccec3158ef8b07b9778f61e9f59030ad2e9e5550->enter($__internal_478a4ca51a49a13bdb140abdccec3158ef8b07b9778f61e9f59030ad2e9e5550_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_478a4ca51a49a13bdb140abdccec3158ef8b07b9778f61e9f59030ad2e9e5550->leave($__internal_478a4ca51a49a13bdb140abdccec3158ef8b07b9778f61e9f59030ad2e9e5550_prof);

        
        $__internal_e8fbc9e2f50c5225c0de9571a21eaa01ebe4af8fdf0c6c7d91fff5b62c671380->leave($__internal_e8fbc9e2f50c5225c0de9571a21eaa01ebe4af8fdf0c6c7d91fff5b62c671380_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
