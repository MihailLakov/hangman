<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_b3eea5658d371baf432e0acc2a63b6b64484a8bed519c05c3b2df3694ae1b388 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd97706195999177b23d33bb4207bb6d431997e4d51c3cde6e920bbf994af5bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd97706195999177b23d33bb4207bb6d431997e4d51c3cde6e920bbf994af5bd->enter($__internal_dd97706195999177b23d33bb4207bb6d431997e4d51c3cde6e920bbf994af5bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_5a549b4beb5c6052f552f5ebb15082569dcd0231181b14d1594eada67be50268 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a549b4beb5c6052f552f5ebb15082569dcd0231181b14d1594eada67be50268->enter($__internal_5a549b4beb5c6052f552f5ebb15082569dcd0231181b14d1594eada67be50268_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_dd97706195999177b23d33bb4207bb6d431997e4d51c3cde6e920bbf994af5bd->leave($__internal_dd97706195999177b23d33bb4207bb6d431997e4d51c3cde6e920bbf994af5bd_prof);

        
        $__internal_5a549b4beb5c6052f552f5ebb15082569dcd0231181b14d1594eada67be50268->leave($__internal_5a549b4beb5c6052f552f5ebb15082569dcd0231181b14d1594eada67be50268_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
