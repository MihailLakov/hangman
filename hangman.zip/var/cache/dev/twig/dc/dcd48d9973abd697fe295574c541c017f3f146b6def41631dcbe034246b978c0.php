<?php

/* :word:show.html.twig */
class __TwigTemplate_0f4d8a6c5c06e05129650312d6523607e0e135b5f84b18151675ce2be4c64861 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":word:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36805ace6fba62fa1a5307991cd258e363c3d6a9e4b243b8fd2a989d8ba499d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36805ace6fba62fa1a5307991cd258e363c3d6a9e4b243b8fd2a989d8ba499d3->enter($__internal_36805ace6fba62fa1a5307991cd258e363c3d6a9e4b243b8fd2a989d8ba499d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:show.html.twig"));

        $__internal_f3a90de00e39a4ff71441d22686a6fff156885350c5fa84a29a8d48d009aecd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3a90de00e39a4ff71441d22686a6fff156885350c5fa84a29a8d48d009aecd5->enter($__internal_f3a90de00e39a4ff71441d22686a6fff156885350c5fa84a29a8d48d009aecd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":word:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_36805ace6fba62fa1a5307991cd258e363c3d6a9e4b243b8fd2a989d8ba499d3->leave($__internal_36805ace6fba62fa1a5307991cd258e363c3d6a9e4b243b8fd2a989d8ba499d3_prof);

        
        $__internal_f3a90de00e39a4ff71441d22686a6fff156885350c5fa84a29a8d48d009aecd5->leave($__internal_f3a90de00e39a4ff71441d22686a6fff156885350c5fa84a29a8d48d009aecd5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0ed9d15e232aa444eb1e083cf85541688431e6026854807c0068f3fc9e28d293 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ed9d15e232aa444eb1e083cf85541688431e6026854807c0068f3fc9e28d293->enter($__internal_0ed9d15e232aa444eb1e083cf85541688431e6026854807c0068f3fc9e28d293_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_287a9c7e5ae8e42dc1f987957ba7216eea27e425f2847bcf6b7f5b1289835168 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_287a9c7e5ae8e42dc1f987957ba7216eea27e425f2847bcf6b7f5b1289835168->enter($__internal_287a9c7e5ae8e42dc1f987957ba7216eea27e425f2847bcf6b7f5b1289835168_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word</h1>
                    <table class=\"table table-striped\">
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "id", array()), "html", null, true);
        echo "</td>
                            </tr>
                            <tr>
                                <th>Word</th>
                                <td>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "word", array()), "html", null, true);
        echo "</td>
                            </tr>
                            <tr>
                                <th>Category</th>
                                <td>";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "category", array()), "title", array()), "html", null, true);
        echo "</td>
                            </tr>
                            <tr>
                                <th>Hint</th>
                                <td>";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "hint", array()), "html", null, true);
        echo "</td>
                            </tr>
                        </tbody>
                    </table>

                    <ul>
                        <li>
                            <a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_edit", array("id" => $this->getAttribute((isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            ";
        // line 40
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_287a9c7e5ae8e42dc1f987957ba7216eea27e425f2847bcf6b7f5b1289835168->leave($__internal_287a9c7e5ae8e42dc1f987957ba7216eea27e425f2847bcf6b7f5b1289835168_prof);

        
        $__internal_0ed9d15e232aa444eb1e083cf85541688431e6026854807c0068f3fc9e28d293->leave($__internal_0ed9d15e232aa444eb1e083cf85541688431e6026854807c0068f3fc9e28d293_prof);

    }

    public function getTemplateName()
    {
        return ":word:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 40,  103 => 38,  97 => 35,  91 => 32,  81 => 25,  74 => 21,  67 => 17,  60 => 13,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Word</h1>
                    <table class=\"table table-striped\">
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <td>{{ word.id }}</td>
                            </tr>
                            <tr>
                                <th>Word</th>
                                <td>{{ word.word }}</td>
                            </tr>
                            <tr>
                                <th>Category</th>
                                <td>{{ word.category.title }}</td>
                            </tr>
                            <tr>
                                <th>Hint</th>
                                <td>{{ word.hint }}</td>
                            </tr>
                        </tbody>
                    </table>

                    <ul>
                        <li>
                            <a href=\"{{ path('word_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                        <li>
                            <a href=\"{{ path('word_edit', { 'id': word.id }) }}\" class=\"btn btn-primary\">Edit</a>
                        </li>
                        <li>
                            {{ form_start(delete_form) }}
                            <input type=\"submit\" value=\"Delete\" class=\"btn btn-danger\">
                            {{ form_end(delete_form) }}
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":word:show.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/word/show.html.twig");
    }
}
