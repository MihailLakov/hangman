<?php

/* default/index.html.twig */
class __TwigTemplate_29998706c2ab56b81db21663efd68d05ae9a0839ec6765521bacccbc82011bd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f0ee51432e6ce2e2f0ac1a575dea5359ac594d4ac5ba054a29472f5a20e767db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0ee51432e6ce2e2f0ac1a575dea5359ac594d4ac5ba054a29472f5a20e767db->enter($__internal_f0ee51432e6ce2e2f0ac1a575dea5359ac594d4ac5ba054a29472f5a20e767db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_0c8124ebd94fbec2df0a7df1db21d481561b88beede85dbac1e702a9ebbdbfe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c8124ebd94fbec2df0a7df1db21d481561b88beede85dbac1e702a9ebbdbfe7->enter($__internal_0c8124ebd94fbec2df0a7df1db21d481561b88beede85dbac1e702a9ebbdbfe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f0ee51432e6ce2e2f0ac1a575dea5359ac594d4ac5ba054a29472f5a20e767db->leave($__internal_f0ee51432e6ce2e2f0ac1a575dea5359ac594d4ac5ba054a29472f5a20e767db_prof);

        
        $__internal_0c8124ebd94fbec2df0a7df1db21d481561b88beede85dbac1e702a9ebbdbfe7->leave($__internal_0c8124ebd94fbec2df0a7df1db21d481561b88beede85dbac1e702a9ebbdbfe7_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_982b7d1c77fc272c701a05affea308a75828ddcca9aca308d9cfaa614416cc15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_982b7d1c77fc272c701a05affea308a75828ddcca9aca308d9cfaa614416cc15->enter($__internal_982b7d1c77fc272c701a05affea308a75828ddcca9aca308d9cfaa614416cc15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_438381cce4f994e39b31d50662530a52efc9ea77793ecfb3740dfb525eb98c89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_438381cce4f994e39b31d50662530a52efc9ea77793ecfb3740dfb525eb98c89->enter($__internal_438381cce4f994e39b31d50662530a52efc9ea77793ecfb3740dfb525eb98c89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Welcome to Hangman game</h1>     
                    <hr>
                    <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Start a new game!</a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_438381cce4f994e39b31d50662530a52efc9ea77793ecfb3740dfb525eb98c89->leave($__internal_438381cce4f994e39b31d50662530a52efc9ea77793ecfb3740dfb525eb98c89_prof);

        
        $__internal_982b7d1c77fc272c701a05affea308a75828ddcca9aca308d9cfaa614416cc15->leave($__internal_982b7d1c77fc272c701a05affea308a75828ddcca9aca308d9cfaa614416cc15_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 9,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Welcome to Hangman game</h1>     
                    <hr>
                    <a href=\"{{ path('game') }}\" class=\"btn btn-lg btn-primary btn-block\">Start a new game!</a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "default/index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\default\\index.html.twig");
    }
}
