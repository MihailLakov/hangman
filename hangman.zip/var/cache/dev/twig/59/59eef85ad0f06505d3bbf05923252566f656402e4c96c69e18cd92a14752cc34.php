<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_37b84cc9d2ae3a5fdb9615553724a2695ff54b4b001906a4b68ae2fe0319eef7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c4b7ccc6711e942878bc49dbbe3f6bdd294c8d94e2eb9817dcc17f60c069f9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c4b7ccc6711e942878bc49dbbe3f6bdd294c8d94e2eb9817dcc17f60c069f9b->enter($__internal_4c4b7ccc6711e942878bc49dbbe3f6bdd294c8d94e2eb9817dcc17f60c069f9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_5c882c132b5c7d2e91ff689d5a28d59fdab63d61d342212e1727443b00546b2e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c882c132b5c7d2e91ff689d5a28d59fdab63d61d342212e1727443b00546b2e->enter($__internal_5c882c132b5c7d2e91ff689d5a28d59fdab63d61d342212e1727443b00546b2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_4c4b7ccc6711e942878bc49dbbe3f6bdd294c8d94e2eb9817dcc17f60c069f9b->leave($__internal_4c4b7ccc6711e942878bc49dbbe3f6bdd294c8d94e2eb9817dcc17f60c069f9b_prof);

        
        $__internal_5c882c132b5c7d2e91ff689d5a28d59fdab63d61d342212e1727443b00546b2e->leave($__internal_5c882c132b5c7d2e91ff689d5a28d59fdab63d61d342212e1727443b00546b2e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
