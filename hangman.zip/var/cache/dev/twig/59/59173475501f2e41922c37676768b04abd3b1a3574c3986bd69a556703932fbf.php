<?php

/* :category:index.html.twig */
class __TwigTemplate_3a44f3a789a955c23c476cdebffc2624710414d49d40d6094a56d01d8f0fa913 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97b71074c0832504e73fd166322d17729fc5e88b2c1632573781e732f620f155 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97b71074c0832504e73fd166322d17729fc5e88b2c1632573781e732f620f155->enter($__internal_97b71074c0832504e73fd166322d17729fc5e88b2c1632573781e732f620f155_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:index.html.twig"));

        $__internal_7d998a6431d23a9725ad21b381b29e5698877fdf524443f8b92793d6bdb15b51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d998a6431d23a9725ad21b381b29e5698877fdf524443f8b92793d6bdb15b51->enter($__internal_7d998a6431d23a9725ad21b381b29e5698877fdf524443f8b92793d6bdb15b51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_97b71074c0832504e73fd166322d17729fc5e88b2c1632573781e732f620f155->leave($__internal_97b71074c0832504e73fd166322d17729fc5e88b2c1632573781e732f620f155_prof);

        
        $__internal_7d998a6431d23a9725ad21b381b29e5698877fdf524443f8b92793d6bdb15b51->leave($__internal_7d998a6431d23a9725ad21b381b29e5698877fdf524443f8b92793d6bdb15b51_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d21411639a4660863d64b2c5cd719aa15e6a638da1b40c258c10e9a5bd3d7c95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d21411639a4660863d64b2c5cd719aa15e6a638da1b40c258c10e9a5bd3d7c95->enter($__internal_d21411639a4660863d64b2c5cd719aa15e6a638da1b40c258c10e9a5bd3d7c95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b0a8236d66600637d818dc56586437194440229b5c0b388778d0323276fc48e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0a8236d66600637d818dc56586437194440229b5c0b388778d0323276fc48e0->enter($__internal_b0a8236d66600637d818dc56586437194440229b5c0b388778d0323276fc48e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Categories list</h1>
                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 19
            echo "                                <tr>
                                    <td><a href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
            echo "</a></td>
                                    <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "title", array()), "html", null, true);
            echo "</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-info\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_new");
        echo "\" class=\"btn btn-primary\">Create a new category</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_b0a8236d66600637d818dc56586437194440229b5c0b388778d0323276fc48e0->leave($__internal_b0a8236d66600637d818dc56586437194440229b5c0b388778d0323276fc48e0_prof);

        
        $__internal_d21411639a4660863d64b2c5cd719aa15e6a638da1b40c258c10e9a5bd3d7c95->leave($__internal_d21411639a4660863d64b2c5cd719aa15e6a638da1b40c258c10e9a5bd3d7c95_prof);

    }

    public function getTemplateName()
    {
        return ":category:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 38,  103 => 34,  91 => 28,  85 => 25,  78 => 21,  72 => 20,  69 => 19,  65 => 18,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Categories list</h1>
                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for category in categories %}
                                <tr>
                                    <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                                    <td>{{ category.title }}</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"{{ path('category_show', { 'id': category.id }) }}\" class=\"btn btn-info\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"{{ path('category_edit', { 'id': category.id }) }}\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_new') }}\" class=\"btn btn-primary\">Create a new category</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", ":category:index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/category/index.html.twig");
    }
}
