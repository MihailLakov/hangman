<?php

/* admin/index.html.twig */
class __TwigTemplate_a53346b7531a5f0098d37cd3cc447c48bce41b2d3be522a7557b05bdf997063c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "admin/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9dcb40fbdb3f14a811040f82ec878fd3874f232036f866d60320465702663fb6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9dcb40fbdb3f14a811040f82ec878fd3874f232036f866d60320465702663fb6->enter($__internal_9dcb40fbdb3f14a811040f82ec878fd3874f232036f866d60320465702663fb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $__internal_621c4f5cfa5f74069daee6553410ae7a6cb6e59ede752b3ecade9ecacbef7e04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_621c4f5cfa5f74069daee6553410ae7a6cb6e59ede752b3ecade9ecacbef7e04->enter($__internal_621c4f5cfa5f74069daee6553410ae7a6cb6e59ede752b3ecade9ecacbef7e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9dcb40fbdb3f14a811040f82ec878fd3874f232036f866d60320465702663fb6->leave($__internal_9dcb40fbdb3f14a811040f82ec878fd3874f232036f866d60320465702663fb6_prof);

        
        $__internal_621c4f5cfa5f74069daee6553410ae7a6cb6e59ede752b3ecade9ecacbef7e04->leave($__internal_621c4f5cfa5f74069daee6553410ae7a6cb6e59ede752b3ecade9ecacbef7e04_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_be632500b92251fce266924631a0a50fd803ae2166a308b1edee633ad651e1a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be632500b92251fce266924631a0a50fd803ae2166a308b1edee633ad651e1a5->enter($__internal_be632500b92251fce266924631a0a50fd803ae2166a308b1edee633ad651e1a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_79a9b5b469a0748f4bac6267d11b2d6f5c2f8803c5872cad9c774b1220e3a0c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79a9b5b469a0748f4bac6267d11b2d6f5c2f8803c5872cad9c774b1220e3a0c4->enter($__internal_79a9b5b469a0748f4bac6267d11b2d6f5c2f8803c5872cad9c774b1220e3a0c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Admin panel</h1>                
                <hr>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_index");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Manage words</a>
                <hr>
                <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-lg btn-primary btn-block\">Manage categories</a>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_79a9b5b469a0748f4bac6267d11b2d6f5c2f8803c5872cad9c774b1220e3a0c4->leave($__internal_79a9b5b469a0748f4bac6267d11b2d6f5c2f8803c5872cad9c774b1220e3a0c4_prof);

        
        $__internal_be632500b92251fce266924631a0a50fd803ae2166a308b1edee633ad651e1a5->leave($__internal_be632500b92251fce266924631a0a50fd803ae2166a308b1edee633ad651e1a5_prof);

    }

    public function getTemplateName()
    {
        return "admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 11,  57 => 9,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                <h1>Admin panel</h1>                
                <hr>
                <a href=\"{{ path('word_index') }}\" class=\"btn btn-lg btn-primary btn-block\">Manage words</a>
                <hr>
                <a href=\"{{ path('category_index') }}\" class=\"btn btn-lg btn-primary btn-block\">Manage categories</a>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "admin/index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\admin\\index.html.twig");
    }
}
