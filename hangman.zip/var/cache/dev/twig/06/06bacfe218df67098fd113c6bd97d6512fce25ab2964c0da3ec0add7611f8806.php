<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_0aea75d665dc1a0c1ead1d62b1b2ae9fb9d0962565c9b2752540b9172abeb48b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d3c1584a4adcc573ea42632663564ccc735b55b44385782db6f9e1a54048b0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d3c1584a4adcc573ea42632663564ccc735b55b44385782db6f9e1a54048b0f->enter($__internal_8d3c1584a4adcc573ea42632663564ccc735b55b44385782db6f9e1a54048b0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_cfb245f7b261b09eebcd71fb8368b2dd7b0e44312bb446e53d3486bf8e310744 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfb245f7b261b09eebcd71fb8368b2dd7b0e44312bb446e53d3486bf8e310744->enter($__internal_cfb245f7b261b09eebcd71fb8368b2dd7b0e44312bb446e53d3486bf8e310744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_8d3c1584a4adcc573ea42632663564ccc735b55b44385782db6f9e1a54048b0f->leave($__internal_8d3c1584a4adcc573ea42632663564ccc735b55b44385782db6f9e1a54048b0f_prof);

        
        $__internal_cfb245f7b261b09eebcd71fb8368b2dd7b0e44312bb446e53d3486bf8e310744->leave($__internal_cfb245f7b261b09eebcd71fb8368b2dd7b0e44312bb446e53d3486bf8e310744_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
