<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_c6dc804a407f5f31da199d7e77e047a59af06bb530116ff445fea5665f6fe827 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9a32000558a2a9c469f14de8cd31316cbf73c9c61b1ca91a8f188670fccf777 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9a32000558a2a9c469f14de8cd31316cbf73c9c61b1ca91a8f188670fccf777->enter($__internal_d9a32000558a2a9c469f14de8cd31316cbf73c9c61b1ca91a8f188670fccf777_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_276a162dc8c92e2b6adad7a6e0c3cedcce02838f77eef058427786c787e9f42c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_276a162dc8c92e2b6adad7a6e0c3cedcce02838f77eef058427786c787e9f42c->enter($__internal_276a162dc8c92e2b6adad7a6e0c3cedcce02838f77eef058427786c787e9f42c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_d9a32000558a2a9c469f14de8cd31316cbf73c9c61b1ca91a8f188670fccf777->leave($__internal_d9a32000558a2a9c469f14de8cd31316cbf73c9c61b1ca91a8f188670fccf777_prof);

        
        $__internal_276a162dc8c92e2b6adad7a6e0c3cedcce02838f77eef058427786c787e9f42c->leave($__internal_276a162dc8c92e2b6adad7a6e0c3cedcce02838f77eef058427786c787e9f42c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
