<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_3ea4b8004f81ac668e39c490c634f5383600c4ac9ce5148604a822c6f511537d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_371bc5446b0f901c45f3161a5a4acfc7837d6a5b6325e03711ba832b095c8782 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_371bc5446b0f901c45f3161a5a4acfc7837d6a5b6325e03711ba832b095c8782->enter($__internal_371bc5446b0f901c45f3161a5a4acfc7837d6a5b6325e03711ba832b095c8782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_b3d502358584f11e3fe48ae9c2a729542daf6c43e533c2dbe16f659ed5a49730 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3d502358584f11e3fe48ae9c2a729542daf6c43e533c2dbe16f659ed5a49730->enter($__internal_b3d502358584f11e3fe48ae9c2a729542daf6c43e533c2dbe16f659ed5a49730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_371bc5446b0f901c45f3161a5a4acfc7837d6a5b6325e03711ba832b095c8782->leave($__internal_371bc5446b0f901c45f3161a5a4acfc7837d6a5b6325e03711ba832b095c8782_prof);

        
        $__internal_b3d502358584f11e3fe48ae9c2a729542daf6c43e533c2dbe16f659ed5a49730->leave($__internal_b3d502358584f11e3fe48ae9c2a729542daf6c43e533c2dbe16f659ed5a49730_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
