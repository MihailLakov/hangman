<?php

/* footer.html.twig */
class __TwigTemplate_b83aa947454a5a7221fe684811755bf9a39905096ff92546dd4f87468653673d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aae9c5b59cca0c98c4daece55b7af97c25c49ceba3348feb2a882115ba3e8eec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aae9c5b59cca0c98c4daece55b7af97c25c49ceba3348feb2a882115ba3e8eec->enter($__internal_aae9c5b59cca0c98c4daece55b7af97c25c49ceba3348feb2a882115ba3e8eec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "footer.html.twig"));

        $__internal_e6c60f6e5feed8996aa609aa93558d5f29035da812c618dde4284cc2fab8db61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6c60f6e5feed8996aa609aa93558d5f29035da812c618dde4284cc2fab8db61->enter($__internal_e6c60f6e5feed8996aa609aa93558d5f29035da812c618dde4284cc2fab8db61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "footer.html.twig"));

        // line 1
        echo "<footer>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <p> ";
        // line 5
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " &copy; Mihail</p>
            </div>
        </div>
    </div>    
</footer>
       
                
   ";
        
        $__internal_aae9c5b59cca0c98c4daece55b7af97c25c49ceba3348feb2a882115ba3e8eec->leave($__internal_aae9c5b59cca0c98c4daece55b7af97c25c49ceba3348feb2a882115ba3e8eec_prof);

        
        $__internal_e6c60f6e5feed8996aa609aa93558d5f29035da812c618dde4284cc2fab8db61->leave($__internal_e6c60f6e5feed8996aa609aa93558d5f29035da812c618dde4284cc2fab8db61_prof);

    }

    public function getTemplateName()
    {
        return "footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<footer>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\">
                <p> {{ 'now'|date('Y') }} &copy; Mihail</p>
            </div>
        </div>
    </div>    
</footer>
       
                
   ", "footer.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\footer.html.twig");
    }
}
