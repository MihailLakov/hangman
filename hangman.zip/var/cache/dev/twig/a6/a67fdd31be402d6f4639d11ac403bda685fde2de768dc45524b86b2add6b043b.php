<?php

/* :default:403.html.twig */
class __TwigTemplate_668c2b0a5ed452ec5660b754ddf1694ce753e96da150c8cbfadb2cc41b4acfb5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:403.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_909cab02148f3c9f06733440a91c176002e821454adb1822915d7cf33b6c650c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_909cab02148f3c9f06733440a91c176002e821454adb1822915d7cf33b6c650c->enter($__internal_909cab02148f3c9f06733440a91c176002e821454adb1822915d7cf33b6c650c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:403.html.twig"));

        $__internal_35b6bc44c157baeb841d8de9493c550e3481556e3a14435a0f80a4bfae48ff73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35b6bc44c157baeb841d8de9493c550e3481556e3a14435a0f80a4bfae48ff73->enter($__internal_35b6bc44c157baeb841d8de9493c550e3481556e3a14435a0f80a4bfae48ff73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_909cab02148f3c9f06733440a91c176002e821454adb1822915d7cf33b6c650c->leave($__internal_909cab02148f3c9f06733440a91c176002e821454adb1822915d7cf33b6c650c_prof);

        
        $__internal_35b6bc44c157baeb841d8de9493c550e3481556e3a14435a0f80a4bfae48ff73->leave($__internal_35b6bc44c157baeb841d8de9493c550e3481556e3a14435a0f80a4bfae48ff73_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_2d055b01fcd53223d3f6481b8d9ea7285075328258468b6500c0e18a3ec7fbd9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d055b01fcd53223d3f6481b8d9ea7285075328258468b6500c0e18a3ec7fbd9->enter($__internal_2d055b01fcd53223d3f6481b8d9ea7285075328258468b6500c0e18a3ec7fbd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_499ffe40f152e52968f7113eaa2cc3507fe8a8b145f60cc32044842d7afd736e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_499ffe40f152e52968f7113eaa2cc3507fe8a8b145f60cc32044842d7afd736e->enter($__internal_499ffe40f152e52968f7113eaa2cc3507fe8a8b145f60cc32044842d7afd736e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <h1> 403 :(</h1>
            <h2> You tried to access an unauthorised page, please log in to continue</h2>       
            <div class=\"well\">                     
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security-login");
        echo "\" class=\"btn-lg btn-primary\" style=\"margin: 0 auto; position:relative; display:block; max-width:380px;text-align:center;\"> Log in with approriate credentials</a>
            </div>
        </div>
    </div>
";
        
        $__internal_499ffe40f152e52968f7113eaa2cc3507fe8a8b145f60cc32044842d7afd736e->leave($__internal_499ffe40f152e52968f7113eaa2cc3507fe8a8b145f60cc32044842d7afd736e_prof);

        
        $__internal_2d055b01fcd53223d3f6481b8d9ea7285075328258468b6500c0e18a3ec7fbd9->leave($__internal_2d055b01fcd53223d3f6481b8d9ea7285075328258468b6500c0e18a3ec7fbd9_prof);

    }

    public function getTemplateName()
    {
        return ":default:403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <h1> 403 :(</h1>
            <h2> You tried to access an unauthorised page, please log in to continue</h2>       
            <div class=\"well\">                     
                <a href=\"{{path('security-login')}}\" class=\"btn-lg btn-primary\" style=\"margin: 0 auto; position:relative; display:block; max-width:380px;text-align:center;\"> Log in with approriate credentials</a>
            </div>
        </div>
    </div>
{% endblock %}
", ":default:403.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/default/403.html.twig");
    }
}
