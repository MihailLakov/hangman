<?php

/* game/hanged.html.twig */
class __TwigTemplate_f4c73636032173b9ffe15169af8420ef363558afd0dc482c829552008656eef0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "game/hanged.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b29935f7d90eca11957ab5181474d4be6d65fe0982fadcd98284cd907cee57a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b29935f7d90eca11957ab5181474d4be6d65fe0982fadcd98284cd907cee57a->enter($__internal_1b29935f7d90eca11957ab5181474d4be6d65fe0982fadcd98284cd907cee57a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/hanged.html.twig"));

        $__internal_5e331dc8ff9b0e883c7e0092859b05c99e4d8f4fb1138df9985ed94f7038cef9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e331dc8ff9b0e883c7e0092859b05c99e4d8f4fb1138df9985ed94f7038cef9->enter($__internal_5e331dc8ff9b0e883c7e0092859b05c99e4d8f4fb1138df9985ed94f7038cef9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "game/hanged.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1b29935f7d90eca11957ab5181474d4be6d65fe0982fadcd98284cd907cee57a->leave($__internal_1b29935f7d90eca11957ab5181474d4be6d65fe0982fadcd98284cd907cee57a_prof);

        
        $__internal_5e331dc8ff9b0e883c7e0092859b05c99e4d8f4fb1138df9985ed94f7038cef9->leave($__internal_5e331dc8ff9b0e883c7e0092859b05c99e4d8f4fb1138df9985ed94f7038cef9_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_fd4b3708a87aad1c88ff6cd6738aa9dd8c5e623a556d183274029c03f56848f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd4b3708a87aad1c88ff6cd6738aa9dd8c5e623a556d183274029c03f56848f3->enter($__internal_fd4b3708a87aad1c88ff6cd6738aa9dd8c5e623a556d183274029c03f56848f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e4dedae735660f149ba29f11def13e79e8ab68aeec1a5dc24a03d8431c8e0b52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4dedae735660f149ba29f11def13e79e8ab68aeec1a5dc24a03d8431c8e0b52->enter($__internal_e4dedae735660f149ba29f11def13e79e8ab68aeec1a5dc24a03d8431c8e0b52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    <h2>
                        Bad luck! The word was <strong>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["word"]) ? $context["word"] : $this->getContext($context, "word")), "html", null, true);
        echo "</strong>.
                    </h2>           
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("game_reset");
        echo "\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
                <div class=\"col-xs-6\">
                    <img src=\"/img/0.png\" alt=\"hangman\" class=\"img-responsive\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_e4dedae735660f149ba29f11def13e79e8ab68aeec1a5dc24a03d8431c8e0b52->leave($__internal_e4dedae735660f149ba29f11def13e79e8ab68aeec1a5dc24a03d8431c8e0b52_prof);

        
        $__internal_fd4b3708a87aad1c88ff6cd6738aa9dd8c5e623a556d183274029c03f56848f3->leave($__internal_fd4b3708a87aad1c88ff6cd6738aa9dd8c5e623a556d183274029c03f56848f3_prof);

    }

    public function getTemplateName()
    {
        return "game/hanged.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 10,  56 => 8,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <div class=\"container\">
        <div class=\"jumbotron\">
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    <h2>
                        Bad luck! The word was <strong>{{ word }}</strong>.
                    </h2>           
                    <a href=\"{{ path('game_reset')}}\" class=\"btn btn-lg btn-primary\"> Start a new game </a>
                </div>
                <div class=\"col-xs-6\">
                    <img src=\"/img/0.png\" alt=\"hangman\" class=\"img-responsive\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "game/hanged.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\game\\hanged.html.twig");
    }
}
