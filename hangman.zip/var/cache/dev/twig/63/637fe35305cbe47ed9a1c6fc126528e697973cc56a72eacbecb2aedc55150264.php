<?php

/* word/index.html.twig */
class __TwigTemplate_7a4467503890b0eae79602b252d3bb0ad95c04821fbd6bc4a083959933ba64ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "word/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce1482bf61643eef88ef72bf5ea2ae31201a07108bb5deb0c39f1151fed0a0f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce1482bf61643eef88ef72bf5ea2ae31201a07108bb5deb0c39f1151fed0a0f1->enter($__internal_ce1482bf61643eef88ef72bf5ea2ae31201a07108bb5deb0c39f1151fed0a0f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/index.html.twig"));

        $__internal_29f63228ae31369f0bd437a470b27e1b79803e9eb3f0e1b9aa08e899d6ca978b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29f63228ae31369f0bd437a470b27e1b79803e9eb3f0e1b9aa08e899d6ca978b->enter($__internal_29f63228ae31369f0bd437a470b27e1b79803e9eb3f0e1b9aa08e899d6ca978b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "word/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ce1482bf61643eef88ef72bf5ea2ae31201a07108bb5deb0c39f1151fed0a0f1->leave($__internal_ce1482bf61643eef88ef72bf5ea2ae31201a07108bb5deb0c39f1151fed0a0f1_prof);

        
        $__internal_29f63228ae31369f0bd437a470b27e1b79803e9eb3f0e1b9aa08e899d6ca978b->leave($__internal_29f63228ae31369f0bd437a470b27e1b79803e9eb3f0e1b9aa08e899d6ca978b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f6b669bd5b5eb77c90183ce8f0239d7620a7dfc1fe447f2b64ae9ded7e5feaa0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6b669bd5b5eb77c90183ce8f0239d7620a7dfc1fe447f2b64ae9ded7e5feaa0->enter($__internal_f6b669bd5b5eb77c90183ce8f0239d7620a7dfc1fe447f2b64ae9ded7e5feaa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4d11ff0a56004e5977723f61875e86527a75732d5ee808f22eb70cc5f209a3ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d11ff0a56004e5977723f61875e86527a75732d5ee808f22eb70cc5f209a3ee->enter($__internal_4d11ff0a56004e5977723f61875e86527a75732d5ee808f22eb70cc5f209a3ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Words list</h1>

                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Word</th>
                                <th>Category</th>
                                <th>Hint</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["words"]) ? $context["words"] : $this->getContext($context, "words")));
        foreach ($context['_seq'] as $context["_key"] => $context["word"]) {
            // line 22
            echo "                                <tr>
                                    <td><a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_show", array("id" => $this->getAttribute($context["word"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["word"], "id", array()), "html", null, true);
            echo "</a></td>
                                    <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["word"], "word", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["word"], "category", array()), "title", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["word"], "hint", array()), "html", null, true);
            echo "</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_show", array("id" => $this->getAttribute($context["word"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_edit", array("id" => $this->getAttribute($context["word"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['word'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "                        </tbody>
                    </table>

                    <ul>
                        <li>
                            <a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("word_new");
        echo "\" class=\"btn btn-primary\">Create a new word</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_4d11ff0a56004e5977723f61875e86527a75732d5ee808f22eb70cc5f209a3ee->leave($__internal_4d11ff0a56004e5977723f61875e86527a75732d5ee808f22eb70cc5f209a3ee_prof);

        
        $__internal_f6b669bd5b5eb77c90183ce8f0239d7620a7dfc1fe447f2b64ae9ded7e5feaa0->leave($__internal_f6b669bd5b5eb77c90183ce8f0239d7620a7dfc1fe447f2b64ae9ded7e5feaa0_prof);

    }

    public function getTemplateName()
    {
        return "word/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 44,  114 => 39,  102 => 33,  96 => 30,  89 => 26,  85 => 25,  81 => 24,  75 => 23,  72 => 22,  68 => 21,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Words list</h1>

                    <table class=\"table table-striped\">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Word</th>
                                <th>Category</th>
                                <th>Hint</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for word in words %}
                                <tr>
                                    <td><a href=\"{{ path('word_show', { 'id': word.id }) }}\" class=\"btn btn-primary\">{{ word.id }}</a></td>
                                    <td>{{ word.word }}</td>
                                    <td>{{ word.category.title }}</td>
                                    <td>{{ word.hint }}</td>
                                    <td>
                                        <ul>
                                            <li>
                                                <a href=\"{{ path('word_show', { 'id': word.id }) }}\" class=\"btn btn-primary\">show</a>
                                            </li>
                                            <li>
                                                <a href=\"{{ path('word_edit', { 'id': word.id }) }}\" class=\"btn btn-primary\">edit</a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            {% endfor %}
                        </tbody>
                    </table>

                    <ul>
                        <li>
                            <a href=\"{{ path('word_new') }}\" class=\"btn btn-primary\">Create a new word</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "word/index.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\word\\index.html.twig");
    }
}
