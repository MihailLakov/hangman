<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_dadd127a96dd7a91ffcb3f0cf440aed53fa5c882e505095f72312c599bbbf48d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa9d85014843320910078e04bc4cdf67fff568f990e22111e104571949221810 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa9d85014843320910078e04bc4cdf67fff568f990e22111e104571949221810->enter($__internal_aa9d85014843320910078e04bc4cdf67fff568f990e22111e104571949221810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_9054d522ff7c6ff44fe55b0b422a91c7db88c19ddd5b301f4d493f5f4100d4f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9054d522ff7c6ff44fe55b0b422a91c7db88c19ddd5b301f4d493f5f4100d4f2->enter($__internal_9054d522ff7c6ff44fe55b0b422a91c7db88c19ddd5b301f4d493f5f4100d4f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_aa9d85014843320910078e04bc4cdf67fff568f990e22111e104571949221810->leave($__internal_aa9d85014843320910078e04bc4cdf67fff568f990e22111e104571949221810_prof);

        
        $__internal_9054d522ff7c6ff44fe55b0b422a91c7db88c19ddd5b301f4d493f5f4100d4f2->leave($__internal_9054d522ff7c6ff44fe55b0b422a91c7db88c19ddd5b301f4d493f5f4100d4f2_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_804e7b0fd8a7ce4ca3c3f770df82a6e0cc8374405d4dae440982031164cff8d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_804e7b0fd8a7ce4ca3c3f770df82a6e0cc8374405d4dae440982031164cff8d9->enter($__internal_804e7b0fd8a7ce4ca3c3f770df82a6e0cc8374405d4dae440982031164cff8d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7179783e98287f0ce18713b53b2ea879099ff520ef8f91269b4f5db386a8c87b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7179783e98287f0ce18713b53b2ea879099ff520ef8f91269b4f5db386a8c87b->enter($__internal_7179783e98287f0ce18713b53b2ea879099ff520ef8f91269b4f5db386a8c87b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_7179783e98287f0ce18713b53b2ea879099ff520ef8f91269b4f5db386a8c87b->leave($__internal_7179783e98287f0ce18713b53b2ea879099ff520ef8f91269b4f5db386a8c87b_prof);

        
        $__internal_804e7b0fd8a7ce4ca3c3f770df82a6e0cc8374405d4dae440982031164cff8d9->leave($__internal_804e7b0fd8a7ce4ca3c3f770df82a6e0cc8374405d4dae440982031164cff8d9_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp2\\htdocs\\hangman\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
