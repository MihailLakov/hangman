<?php

/* default/register.html.twig */
class __TwigTemplate_46ba4ea0523bbe3eed3f034cbbd4211f6ce7eccee88599b48af7f104918e6c3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/register.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38982e83bf3810d2f2a3dd0b3bdd3172e4e3d41fb51adb37fa62540f59c3031d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38982e83bf3810d2f2a3dd0b3bdd3172e4e3d41fb51adb37fa62540f59c3031d->enter($__internal_38982e83bf3810d2f2a3dd0b3bdd3172e4e3d41fb51adb37fa62540f59c3031d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register.html.twig"));

        $__internal_b9f5cbf4bd6bbe7404f1f700410e29992e1e7aa4c7fcf3695604dbc226bb69ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9f5cbf4bd6bbe7404f1f700410e29992e1e7aa4c7fcf3695604dbc226bb69ff->enter($__internal_b9f5cbf4bd6bbe7404f1f700410e29992e1e7aa4c7fcf3695604dbc226bb69ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_38982e83bf3810d2f2a3dd0b3bdd3172e4e3d41fb51adb37fa62540f59c3031d->leave($__internal_38982e83bf3810d2f2a3dd0b3bdd3172e4e3d41fb51adb37fa62540f59c3031d_prof);

        
        $__internal_b9f5cbf4bd6bbe7404f1f700410e29992e1e7aa4c7fcf3695604dbc226bb69ff->leave($__internal_b9f5cbf4bd6bbe7404f1f700410e29992e1e7aa4c7fcf3695604dbc226bb69ff_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_18328827f77d640f84ed5309d42c075b42b9052bd07b27c7cff1d42a59325be2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18328827f77d640f84ed5309d42c075b42b9052bd07b27c7cff1d42a59325be2->enter($__internal_18328827f77d640f84ed5309d42c075b42b9052bd07b27c7cff1d42a59325be2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bdced24bd189998dd93c007ce40f142a83e57f3d27d821d0ad20d3e2473f37f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bdced24bd189998dd93c007ce40f142a83e57f3d27d821d0ad20d3e2473f37f5->enter($__internal_bdced24bd189998dd93c007ce40f142a83e57f3d27d821d0ad20d3e2473f37f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"jumbotron\">
                <h2>Register a new account</h2>
                ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'form_start');
        echo "
                ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'widget');
        echo "
                <input type=\"submit\" value=\"Submit\" class=\"btn btn-primary btn-lg\">
                ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'rest');
        echo "
                ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'form_end');
        echo "
            </div>
        </div>
    </div>
";
        
        $__internal_bdced24bd189998dd93c007ce40f142a83e57f3d27d821d0ad20d3e2473f37f5->leave($__internal_bdced24bd189998dd93c007ce40f142a83e57f3d27d821d0ad20d3e2473f37f5_prof);

        
        $__internal_18328827f77d640f84ed5309d42c075b42b9052bd07b27c7cff1d42a59325be2->leave($__internal_18328827f77d640f84ed5309d42c075b42b9052bd07b27c7cff1d42a59325be2_prof);

    }

    public function getTemplateName()
    {
        return "default/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 12,  64 => 11,  59 => 9,  55 => 8,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"jumbotron\">
                <h2>Register a new account</h2>
                {{ form_start(registerForm) }}
                {{ form_widget(registerForm) }}
                <input type=\"submit\" value=\"Submit\" class=\"btn btn-primary btn-lg\">
                {{ form_rest(registerForm) }}
                {{ form_end(registerForm) }}
            </div>
        </div>
    </div>
{% endblock %}
", "default/register.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\default\\register.html.twig");
    }
}
