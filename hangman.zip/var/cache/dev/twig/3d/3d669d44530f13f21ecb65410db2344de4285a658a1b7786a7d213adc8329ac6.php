<?php

/* category/new.html.twig */
class __TwigTemplate_8f8bc2cc844f52c82aab1097a0b66922580029cd22735e19839eeeda4a4c8198 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6d3c2b3fa56388af2e10c1267ad7a8a6d23ab900c8e1d4ee127b74e426cb61c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6d3c2b3fa56388af2e10c1267ad7a8a6d23ab900c8e1d4ee127b74e426cb61c->enter($__internal_d6d3c2b3fa56388af2e10c1267ad7a8a6d23ab900c8e1d4ee127b74e426cb61c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/new.html.twig"));

        $__internal_febd45a161773de1e6d3e94f493dc0e0b8d2e02374fc41061c511d01fce939a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_febd45a161773de1e6d3e94f493dc0e0b8d2e02374fc41061c511d01fce939a1->enter($__internal_febd45a161773de1e6d3e94f493dc0e0b8d2e02374fc41061c511d01fce939a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d6d3c2b3fa56388af2e10c1267ad7a8a6d23ab900c8e1d4ee127b74e426cb61c->leave($__internal_d6d3c2b3fa56388af2e10c1267ad7a8a6d23ab900c8e1d4ee127b74e426cb61c_prof);

        
        $__internal_febd45a161773de1e6d3e94f493dc0e0b8d2e02374fc41061c511d01fce939a1->leave($__internal_febd45a161773de1e6d3e94f493dc0e0b8d2e02374fc41061c511d01fce939a1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_81de0e32e0358e99d6c29d6af6776ebdb19b039e3180861bba7bbf0110e1bfb8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81de0e32e0358e99d6c29d6af6776ebdb19b039e3180861bba7bbf0110e1bfb8->enter($__internal_81de0e32e0358e99d6c29d6af6776ebdb19b039e3180861bba7bbf0110e1bfb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_92bd76916a3e3401fc703e6d34c21ad4281a54c4b8212e025126465a0b83542c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92bd76916a3e3401fc703e6d34c21ad4281a54c4b8212e025126465a0b83542c->enter($__internal_92bd76916a3e3401fc703e6d34c21ad4281a54c4b8212e025126465a0b83542c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category creation</h1>

                    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\"/>
                    ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

                    <ul>
                        <li>
                            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_92bd76916a3e3401fc703e6d34c21ad4281a54c4b8212e025126465a0b83542c->leave($__internal_92bd76916a3e3401fc703e6d34c21ad4281a54c4b8212e025126465a0b83542c_prof);

        
        $__internal_81de0e32e0358e99d6c29d6af6776ebdb19b039e3180861bba7bbf0110e1bfb8->leave($__internal_81de0e32e0358e99d6c29d6af6776ebdb19b039e3180861bba7bbf0110e1bfb8_prof);

    }

    public function getTemplateName()
    {
        return "category/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 17,  66 => 13,  61 => 11,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12\"> 
                <div class=\"jumbotron\">
                    <h1>Category creation</h1>

                    {{ form_start(form) }}
                    {{ form_widget(form) }}
                    <input type=\"submit\" value=\"Create\" class=\"btn btn-primary\"/>
                    {{ form_end(form) }}

                    <ul>
                        <li>
                            <a href=\"{{ path('category_index') }}\" class=\"btn btn-primary\">Back to the list</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "category/new.html.twig", "C:\\xampp2\\htdocs\\hangman\\app\\Resources\\views\\category\\new.html.twig");
    }
}
