<?php

/* ::base.html.twig */
class __TwigTemplate_e5aaa710ad05ff01d8c08fb3f7784e54091a35f64b96d647d3dca94f1a0868b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9db2fb2606ec64ddd85e0f7a848bb8d3803ce276432b993e2e1ab62dc10160c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9db2fb2606ec64ddd85e0f7a848bb8d3803ce276432b993e2e1ab62dc10160c->enter($__internal_c9db2fb2606ec64ddd85e0f7a848bb8d3803ce276432b993e2e1ab62dc10160c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_88e7ef452a52082e52be598bc32e34641bc60ae03a0bbfea03b2390701ef1d0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88e7ef452a52082e52be598bc32e34641bc60ae03a0bbfea03b2390701ef1d0c->enter($__internal_88e7ef452a52082e52be598bc32e34641bc60ae03a0bbfea03b2390701ef1d0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
        <script
            src=\"https://code.jquery.com/jquery-3.2.1.min.js\"
            integrity=\"sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=\"
        crossorigin=\"anonymous\"></script>        
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\"> 
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
        <link rel=\"stylesheet\" href=\"/css/main.css\">
        <script src=\"/js/main.js\" type=\"text/javascript\"></script>
    </head>
    <body>
        ";
        // line 18
        $this->loadTemplate("header.html.twig", "::base.html.twig", 18)->display($context);
        // line 19
        echo "        <div class=\"page-wrap\">
        ";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 21
        echo "         </div>
        ";
        // line 22
        $this->displayBlock('javascripts', $context, $blocks);
        // line 23
        echo "        ";
        $this->loadTemplate("footer.html.twig", "::base.html.twig", 23)->display($context);
        // line 24
        echo "    </body>
</html>
";
        
        $__internal_c9db2fb2606ec64ddd85e0f7a848bb8d3803ce276432b993e2e1ab62dc10160c->leave($__internal_c9db2fb2606ec64ddd85e0f7a848bb8d3803ce276432b993e2e1ab62dc10160c_prof);

        
        $__internal_88e7ef452a52082e52be598bc32e34641bc60ae03a0bbfea03b2390701ef1d0c->leave($__internal_88e7ef452a52082e52be598bc32e34641bc60ae03a0bbfea03b2390701ef1d0c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_e12c1bf70d153deb82d101cffb986e1130cc62fd308a84247b2cff6a2d6f9239 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e12c1bf70d153deb82d101cffb986e1130cc62fd308a84247b2cff6a2d6f9239->enter($__internal_e12c1bf70d153deb82d101cffb986e1130cc62fd308a84247b2cff6a2d6f9239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_10060a8e86b59b98cf3ee92b706f00b73bb0dd6057eeafe179e4a0a23913ede3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10060a8e86b59b98cf3ee92b706f00b73bb0dd6057eeafe179e4a0a23913ede3->enter($__internal_10060a8e86b59b98cf3ee92b706f00b73bb0dd6057eeafe179e4a0a23913ede3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Hangman game!";
        
        $__internal_10060a8e86b59b98cf3ee92b706f00b73bb0dd6057eeafe179e4a0a23913ede3->leave($__internal_10060a8e86b59b98cf3ee92b706f00b73bb0dd6057eeafe179e4a0a23913ede3_prof);

        
        $__internal_e12c1bf70d153deb82d101cffb986e1130cc62fd308a84247b2cff6a2d6f9239->leave($__internal_e12c1bf70d153deb82d101cffb986e1130cc62fd308a84247b2cff6a2d6f9239_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7b2e4331b64af7b15b6decafb3645c519eea1f4feccc34419c5f0382af4de8aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7b2e4331b64af7b15b6decafb3645c519eea1f4feccc34419c5f0382af4de8aa->enter($__internal_7b2e4331b64af7b15b6decafb3645c519eea1f4feccc34419c5f0382af4de8aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_42ab4dfa6baa4d1c6ac4014d589dc48a9f14f204ad5d1c7e63c8693924f933e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42ab4dfa6baa4d1c6ac4014d589dc48a9f14f204ad5d1c7e63c8693924f933e1->enter($__internal_42ab4dfa6baa4d1c6ac4014d589dc48a9f14f204ad5d1c7e63c8693924f933e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_42ab4dfa6baa4d1c6ac4014d589dc48a9f14f204ad5d1c7e63c8693924f933e1->leave($__internal_42ab4dfa6baa4d1c6ac4014d589dc48a9f14f204ad5d1c7e63c8693924f933e1_prof);

        
        $__internal_7b2e4331b64af7b15b6decafb3645c519eea1f4feccc34419c5f0382af4de8aa->leave($__internal_7b2e4331b64af7b15b6decafb3645c519eea1f4feccc34419c5f0382af4de8aa_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_abfe3934756c6278dddc3522c7538eacfcd3804a4e7dfd379a528630e4d1d9ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_abfe3934756c6278dddc3522c7538eacfcd3804a4e7dfd379a528630e4d1d9ac->enter($__internal_abfe3934756c6278dddc3522c7538eacfcd3804a4e7dfd379a528630e4d1d9ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_20d494bd646bbb17dfe593c3a073f30c58132afc51a5042b0579a596486b0ab7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20d494bd646bbb17dfe593c3a073f30c58132afc51a5042b0579a596486b0ab7->enter($__internal_20d494bd646bbb17dfe593c3a073f30c58132afc51a5042b0579a596486b0ab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_20d494bd646bbb17dfe593c3a073f30c58132afc51a5042b0579a596486b0ab7->leave($__internal_20d494bd646bbb17dfe593c3a073f30c58132afc51a5042b0579a596486b0ab7_prof);

        
        $__internal_abfe3934756c6278dddc3522c7538eacfcd3804a4e7dfd379a528630e4d1d9ac->leave($__internal_abfe3934756c6278dddc3522c7538eacfcd3804a4e7dfd379a528630e4d1d9ac_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_30ee32aba230c68505398fc3468be4705261eb4f96a1f1951e14934885ef7844 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30ee32aba230c68505398fc3468be4705261eb4f96a1f1951e14934885ef7844->enter($__internal_30ee32aba230c68505398fc3468be4705261eb4f96a1f1951e14934885ef7844_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_87685a5be4b86c7fed04ffec78c38f0783e7ab34b12b862b9840146ed783d451 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87685a5be4b86c7fed04ffec78c38f0783e7ab34b12b862b9840146ed783d451->enter($__internal_87685a5be4b86c7fed04ffec78c38f0783e7ab34b12b862b9840146ed783d451_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_87685a5be4b86c7fed04ffec78c38f0783e7ab34b12b862b9840146ed783d451->leave($__internal_87685a5be4b86c7fed04ffec78c38f0783e7ab34b12b862b9840146ed783d451_prof);

        
        $__internal_30ee32aba230c68505398fc3468be4705261eb4f96a1f1951e14934885ef7844->leave($__internal_30ee32aba230c68505398fc3468be4705261eb4f96a1f1951e14934885ef7844_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 22,  118 => 20,  101 => 6,  83 => 5,  71 => 24,  68 => 23,  66 => 22,  63 => 21,  61 => 20,  58 => 19,  56 => 18,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Hangman game!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
        <script
            src=\"https://code.jquery.com/jquery-3.2.1.min.js\"
            integrity=\"sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=\"
        crossorigin=\"anonymous\"></script>        
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\"> 
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
        <link rel=\"stylesheet\" href=\"/css/main.css\">
        <script src=\"/js/main.js\" type=\"text/javascript\"></script>
    </head>
    <body>
        {% include 'header.html.twig' %}
        <div class=\"page-wrap\">
        {% block body %}{% endblock %}
         </div>
        {% block javascripts %}{% endblock %}
        {% include 'footer.html.twig' %}
    </body>
</html>
", "::base.html.twig", "C:\\xampp2\\htdocs\\hangman\\app/Resources\\views/base.html.twig");
    }
}
